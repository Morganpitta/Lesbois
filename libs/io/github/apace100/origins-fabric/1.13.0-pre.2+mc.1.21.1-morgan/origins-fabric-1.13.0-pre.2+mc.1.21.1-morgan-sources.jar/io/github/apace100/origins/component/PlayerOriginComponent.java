package io.github.apace100.origins.component;

import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.mojang.serialization.JsonOps;
import io.github.apace100.apoli.component.PowerHolderComponent;
import io.github.apace100.apoli.power.Power;
import io.github.apace100.apoli.power.PowerManager;
import io.github.apace100.origins.Origins;
import io.github.apace100.origins.origin.*;
import io.github.apace100.origins.registry.ModComponents;
import io.github.apace100.origins.util.ChoseOriginCriterion;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Predicate;
import net.minecraft.class_1657;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_6903;
import net.minecraft.class_7225;

public class PlayerOriginComponent implements OriginComponent {

    private final Map<OriginLayer, Origin> origins = new ConcurrentHashMap<>();
    private final class_1657 player;

    private boolean selectingOrigin = false;
    private boolean hadOriginBefore = false;

    private int invulnerabilityTicks = 0;

    public PlayerOriginComponent(class_1657 player) {
        this.player = player;
    }

    @Override
    public boolean hasSelectionInvulnerability() {
        return invulnerabilityTicks > 0;
    }

    @Override
    public boolean isSelectingOrigin() {
        return selectingOrigin;
    }

    @Override
    public void selectingOrigin(boolean selectingOrigin) {

        this.selectingOrigin = selectingOrigin;

        if (selectingOrigin && !player.method_37908().field_9236) {
            invulnerabilityTicks = 60;
        }

    }

    @Override
    public boolean hasAllOrigins() {

        for (var layer : OriginLayerManager.values()) {

	        if (layer.isEnabled() && (!layer.getOrigins().isEmpty() && layer.getOriginOptionCount(player) >= 1) && !hasOrigin(layer)) {
		        return false;
	        }

        }

        return true;

    }

    @Override
    public Map<OriginLayer, Origin> getOrigins() {
        return origins;
    }

    @Override
    public boolean hasOrigin(OriginLayer layer) {
        return origins.containsKey(layer)
            && origins.get(layer) != Origin.EMPTY;
    }

    @Override
    public Origin getOrigin(OriginLayer layer) {

        if (OriginLayerManager.contains(layer)) {
            return origins.computeIfAbsent(layer, k -> Origin.EMPTY);
        }

        else {
            return origins.getOrDefault(layer, Origin.EMPTY);
        }

    }

    @Override
    public boolean hadOriginBefore() {
        return hadOriginBefore;
    }

    @Override
    public void removeLayer(OriginLayer layer) {

        Origin oldOrigin = getOrigin(layer);
        if (oldOrigin != null) {
            PowerHolderComponent.KEY.get(player).removeAllPowersFromSource(oldOrigin.getId());
        }

        origins.remove(layer);

    }

    @Override
    public void setOrigin(OriginLayer layer, Origin origin) {

        Origin oldOrigin = getOrigin(layer);
        if (origin == oldOrigin) {
            return;
        }

        PowerHolderComponent powerComponent = PowerHolderComponent.KEY.get(player);
        class_6903<JsonElement> jsonOps = player.method_56673().method_57093(JsonOps.INSTANCE);

        if (oldOrigin != null) {

            JsonElement oldOriginJson = Origin.DATA_TYPE.write(jsonOps, oldOrigin).getOrThrow(JsonParseException::new);
            JsonElement originJson = Origin.DATA_TYPE.write(jsonOps, origin).getOrThrow(JsonParseException::new);

            if (!oldOrigin.getId().equals(origin.getId())) {
                PowerHolderComponent.revokeAllPowersFromSource(player, oldOrigin.getId(), true);
            }

            else if (!oldOriginJson.equals(originJson)) {
                revokeRemovedPowers(origin, powerComponent);
            }

        }

        grantPowersFromOrigin(origin);
        this.origins.put(layer, origin);

        if (this.hasAllOrigins()) {
            this.hadOriginBefore = true;
        }

        if (player instanceof class_3222 spe) {
            ChoseOriginCriterion.INSTANCE.trigger(spe, origin);
        }

    }

    private void grantPowersFromOrigin(Origin origin) {
        PowerHolderComponent.grantPowers(this.player, Map.of(origin.getId(), origin.getPowers()), true);
    }

    private void revokeRemovedPowers(Origin origin, PowerHolderComponent powerComponent) {

        class_2960 sourceId = origin.getId();
        List<Power> powers = powerComponent.getPowersFromSource(sourceId)
            .stream()
            .filter(Predicate.not(origin::hasPower))
            .toList();

        boolean revoked = powers
            .stream()
            .map(pt -> powerComponent.removePower(pt, sourceId))
            .reduce(false, Boolean::logicalOr);

        if (revoked) {
            PowerHolderComponent.PacketHandlers.REVOKE_POWERS.sync(player, Map.of(sourceId, powers));
        }

    }

    @Override
    public void serverTick() {
        if (!selectingOrigin && invulnerabilityTicks > 0) {
            invulnerabilityTicks--;
        }
    }

    @Override
    public void readFromNbt(@NotNull class_2487 compoundTag, class_7225.class_7874 wrapperLookup) {

        if (player == null) {
            Origins.LOGGER.error("Player was null in PlayerOriginComponent#fromTag! This is not supposed to happen D:");
            return;
        }

        PowerHolderComponent powerComponent = PowerHolderComponent.KEY.get(player);
        origins.clear();

        //  Migrate origin data from old versions
        if (compoundTag.method_10545("Origin")) {
            try {

                OriginLayer defaultOriginLayer = OriginLayerManager.get(Origins.identifier("origin"));
                origins.put(defaultOriginLayer, OriginManager.get(class_2960.method_60654(compoundTag.method_10558("Origin"))));

            } catch (Exception ignored) {
                Origins.LOGGER.warn("Player {} had old origin which could not be migrated: {}", player.method_5477().getString(), compoundTag.method_10558("Origin"));
            }
        } else {

            class_2499 originLayersNbt = compoundTag.method_10554("OriginLayers", class_2520.field_33260);
            for (int i = 0; i < originLayersNbt.size(); i++) {

                class_2487 originLayerNbt = originLayersNbt.method_10602(i);
                try {

                    class_2960 layerId = class_2960.method_60654(originLayerNbt.method_10558("Layer"));
                    class_2960 originId = class_2960.method_60654(originLayerNbt.method_10558("Origin"));

                    OriginLayer layer = OriginLayerManager.get(layerId);
                    Origin origin = OriginManager.get(originId);

                    origins.put(layer, origin);

                    if (layer.contains(origin) || origin.isSpecial()) {
                        continue;
                    }

                    Origins.LOGGER.warn("Origin \"{}\" is not in origin layer \"{}\" and is not considered special, but was found on player {}!", originId, layerId, player.method_5477().getString());

                    powerComponent.removeAllPowersFromSource(originId);
                    origins.put(layer, Origin.EMPTY);

                } catch (Exception e) {
                    Origins.LOGGER.error("There was a problem trying to read origin NBT data of player {}: {}", player.method_5477().getString(), e.getMessage());
                }

            }

        }

        selectingOrigin = compoundTag.method_10577("SelectingOrigin");
        hadOriginBefore = compoundTag.method_10577("HadOriginBefore");

        if (player.method_37908().field_9236) {
            return;
        }

        for (Origin origin : origins.values()) {
            //  Grant powers only if the player doesn't have them yet from the specific Origin source.
            //  Needed in case the origin was set before the update to Apoli happened.
            grantPowersFromOrigin(origin);
        }

        for (Origin origin : origins.values()) {
            revokeRemovedPowers(origin, powerComponent);
        }

        //  Compatibility with old worlds. Load power data from Origins' NBT, whereas in new versions, power data is
        //  stored in Apoli's NBT
        if (!compoundTag.method_10545("Powers")) {
            return;
        }

        class_2499 legacyPowersNbt = compoundTag.method_10554("Powers", class_2520.field_33260);
        for (int i = 0; i < legacyPowersNbt.size(); i++) {

            class_2487 legacyPowerNbt = legacyPowersNbt.method_10602(i);
            String legacyPowerString = legacyPowerNbt.method_10558("Type");

            try {

                class_2960 legacyPowerId = class_2960.method_60654(legacyPowerString);
                Power legacyPower = PowerManager.get(legacyPowerId);

                if (!powerComponent.hasPower(legacyPower)) {
                    continue;
                }

                try {
                    class_2520 legacyPowerData = legacyPowerNbt.method_10580("Data");
                    powerComponent.getPowerType(legacyPower).fromTag(legacyPowerData);
                } catch (ClassCastException e) {
                    //  Occurs when the power was overridden by a data pack since last world load
                    //  where the overridden power now uses different data classes
                    Origins.LOGGER.warn("Data type of power \"{}\" changed, skipping data for that power on entity {}", legacyPowerId, player.method_5477().getString());
                }


            } catch (IllegalArgumentException e) {
                Origins.LOGGER.warn("Power data of unregistered power \"{}\" found on player {}, skipping...", legacyPowerString, player.method_5477().getString());
            }

        }

    }

    @Override
    public void writeToNbt(@NotNull class_2487 compoundTag, class_7225.class_7874 wrapperLookup) {

        class_2499 originLayersNbt = new class_2499();
        origins.forEach((layer, origin) -> {

            class_2487 originLayerNbt = new class_2487();

            originLayerNbt.method_10582("Layer", layer.getId().toString());
            originLayerNbt.method_10582("Origin", origin.getId().toString());

            originLayersNbt.add(originLayerNbt);

        });

        compoundTag.method_10566("OriginLayers", originLayersNbt);
        compoundTag.method_10556("SelectingOrigin", selectingOrigin);
        compoundTag.method_10556("HadOriginBefore", hadOriginBefore);

    }

    @Override
    public void sync() {
        ModComponents.ORIGIN.sync(player);
    }

}
