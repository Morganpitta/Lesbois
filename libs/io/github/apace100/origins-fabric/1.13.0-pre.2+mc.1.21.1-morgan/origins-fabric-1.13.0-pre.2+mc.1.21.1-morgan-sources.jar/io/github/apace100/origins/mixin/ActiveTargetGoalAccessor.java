package io.github.apace100.origins.mixin;

import net.minecraft.class_1309;
import net.minecraft.class_1400;
import net.minecraft.class_4051;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_1400.class)
public interface ActiveTargetGoalAccessor extends TrackTargetGoalAccessor {

    @Accessor
    Class<? extends class_1309> getTargetClass();

    @Accessor
    class_4051 getTargetPredicate();

    @Accessor
    int getReciprocalChance();

}
