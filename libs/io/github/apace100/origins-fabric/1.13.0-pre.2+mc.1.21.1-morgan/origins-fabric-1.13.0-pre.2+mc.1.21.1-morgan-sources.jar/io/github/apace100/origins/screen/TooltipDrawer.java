package io.github.apace100.origins.screen;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_327;
import net.minecraft.class_332;

@Environment(EnvType.CLIENT)
public interface TooltipDrawer {

	void renderTooltip(class_327 textRenderer, class_332 context, int mouseX, int mouseY, float delta);

}
