package io.github.apace100.origins.mixin;

import net.minecraft.class_1308;
import net.minecraft.class_1355;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_1308.class)
public interface MobEntityAccessor {

    @Accessor
    class_1355 getTargetSelector();

    @Accessor
    class_1355 getGoalSelector();

}
