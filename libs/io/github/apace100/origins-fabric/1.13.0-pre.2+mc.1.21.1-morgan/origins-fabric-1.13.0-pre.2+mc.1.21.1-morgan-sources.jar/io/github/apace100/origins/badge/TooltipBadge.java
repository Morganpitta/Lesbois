package io.github.apace100.origins.badge;

import io.github.apace100.apoli.power.Power;
import io.github.apace100.calio.data.SerializableData;
import java.util.LinkedList;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_327;
import net.minecraft.class_5481;
import net.minecraft.class_5683;
import net.minecraft.class_5684;

public record TooltipBadge(class_2960 spriteId, class_2561 text) implements Badge {

    public TooltipBadge(SerializableData.Instance instance) {
        this(instance.getId("sprite"), instance.get("text"));
    }

    @Override
    public boolean hasTooltip() {
        return true;
    }

    public static void addLines(List<class_5684> tooltips, class_2561 text, class_327 textRenderer, int widthLimit) {
        if(textRenderer.method_27525(text) > widthLimit) {
            for(class_5481 orderedText : textRenderer.method_1728(text, widthLimit)) {
                tooltips.add(new class_5683(orderedText));
            }
        } else {
            tooltips.add(new class_5683(text.method_30937()));
        }
    }

    @Override
    public List<class_5684> getTooltipComponents(Power power, int widthLimit, float time, class_327 textRenderer) {
        List<class_5684> tooltips = new LinkedList<>();
        addLines(tooltips, text, textRenderer, widthLimit);
        return tooltips;
    }

    @Override
    public SerializableData.Instance toData(SerializableData.Instance instance) {
        instance.set("sprite", spriteId);
        instance.set("text", text);
        return instance;
    }

    @Override
    public BadgeFactory getBadgeFactory() {
        return BadgeFactories.TOOLTIP;
    }

}
