package io.github.apace100.origins.mixin;

import net.minecraft.class_1309;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_1309.class)
public interface LivingEntityAccessor {

    @Invoker
    int callGetNextAirOnLand(int air);

    @Invoker
    int callGetNextAirUnderwater(int air);

}
