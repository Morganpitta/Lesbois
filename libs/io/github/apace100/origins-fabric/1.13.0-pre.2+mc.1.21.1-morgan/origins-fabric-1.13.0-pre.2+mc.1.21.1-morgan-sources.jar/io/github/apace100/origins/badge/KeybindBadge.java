package io.github.apace100.origins.badge;

import io.github.apace100.apoli.power.Power;
import io.github.apace100.apoli.util.keybinding.KeyBindingUtil;
import io.github.apace100.calio.data.SerializableData;
import io.github.apace100.origins.util.PowerKeyManager;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_327;
import net.minecraft.class_5683;
import net.minecraft.class_5684;

public record KeybindBadge(class_2960 spriteId, String text) implements Badge {

    public KeybindBadge(SerializableData.Instance instance) {
        this(instance.getId("sprite"), instance.get("text"));
    }

    @Override
    public boolean hasTooltip() {
        return !text.isEmpty();
    }

    @Override
    public List<class_5684> getTooltipComponents(Power power, int widthLimit, float time, class_327 textRenderer) {

        Optional<String> keyId = PowerKeyManager.getKeyId(power);
        List<class_5684> tooltips = new ObjectArrayList<>();

        if (keyId.isPresent()) {

            class_2561 keyName = KeyBindingUtil.getLocalizedName(keyId.get());
            class_2561 keyText = class_2561.method_43469(text(), class_2561.method_43470("[").method_10852(keyName).method_27693("]"));

            if (textRenderer.method_27525(keyText) > widthLimit) {
                textRenderer.method_1728(keyText, widthLimit)
                    .stream()
                    .map(class_5683::new)
                    .forEach(tooltips::add);
            }

            else {
                tooltips.add(new class_5683(keyText.method_30937()));
            }

        }

        return tooltips;

    }

    @Override
    public SerializableData.Instance toData(SerializableData.Instance instance) {
        instance.set("sprite", spriteId);
        instance.set("text", text);
        return instance;
    }

    @Override
    public BadgeFactory getBadgeFactory() {
        return BadgeFactories.KEYBIND;
    }

}
