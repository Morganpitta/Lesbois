package io.github.apace100.origins.networking.packet;

import io.github.apace100.origins.Origins;
import net.minecraft.class_2540;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

public record VersionHandshakePacket(int[] semver) implements class_8710 {

    private static final class_9139<class_2540, int[]> INT_ARRAY = class_9139.method_56437(class_2540::method_10806, class_2540::method_10787);

    public static final class_9154<VersionHandshakePacket> PACKET_ID = new class_9154<>(Origins.identifier("handshake/version"));
    public static final class_9139<class_2540, VersionHandshakePacket> PACKET_CODEC = INT_ARRAY.method_56432(VersionHandshakePacket::new, VersionHandshakePacket::semver);

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return PACKET_ID;
    }

}
