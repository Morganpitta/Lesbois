package io.github.apace100.origins.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.Map;
import net.minecraft.class_304;

@Mixin(class_304.class)
public interface KeyBindingAccessor {

    @Accessor("KEYS_BY_ID")
    static Map<String, class_304> getKeysById() {
        throw new AssertionError();
    }

}
