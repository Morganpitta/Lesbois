package io.github.apace100.origins.util;

import io.github.apace100.apoli.util.TextAlignment;
import java.util.Optional;
import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_3532;

public class MiscUtilClient {

	public static void drawScrollingText(class_332 context, class_327 renderer, class_2561 text, TextAlignment alignment, int startX, int startY, int endX, int endY, int color, boolean shadow) {

		int textWidth = renderer.method_27525(text);

		int height = (startY + endY - 9) / 2 + 1;
		int width = endX - startX;

		Optional<Integer> horizontalAlignment = alignment.horizontal(startX, endX, textWidth);

		if (textWidth <= width && horizontalAlignment.isPresent()) {
			context.method_51439(renderer, text, horizontalAlignment.get(), height, color, shadow);
		}

		else {

			int horizontalDiff = textWidth - width;

			double d = (double) class_156.method_658() / 1000.0;
			double e = Math.max((double) horizontalDiff * 0.5, 3.0);
			double f = Math.sin((Math.PI / 2) * Math.cos((Math.PI * 2) * d / e)) / 2.0 + 0.5;
			double g = class_3532.method_16436(f, 0.0, horizontalDiff);

			context.method_44379(startX, startY, endX, endY);
			context.method_51439(renderer, text, startX - (int) g, height, color, shadow);
			context.method_44380();

		}

	}

}
