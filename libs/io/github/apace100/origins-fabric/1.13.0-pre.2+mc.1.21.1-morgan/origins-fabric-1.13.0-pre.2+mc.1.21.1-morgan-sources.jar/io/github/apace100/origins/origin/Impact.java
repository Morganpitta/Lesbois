package io.github.apace100.origins.origin;

import io.github.apace100.origins.Origins;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_5250;

public enum Impact {
	
	NONE(0, "none", class_124.field_1080, Origins.identifier("choose_origin/impact/none")),
	LOW(1, "low", class_124.field_1060, Origins.identifier("choose_origin/impact/low")),
	MEDIUM(2, "medium", class_124.field_1054, Origins.identifier("choose_origin/impact/medium")),
	HIGH(3, "high", class_124.field_1061, Origins.identifier("choose_origin/impact/high"));
	
	private final int impactValue;
	private final String translationKey;
	private final class_124 textStyle;
	private final class_2960 spriteId;

	private Impact(int impactValue, String translationKey, class_124 textStyle, class_2960 spriteId) {
		this.translationKey = "origins.gui.impact." + translationKey;
		this.impactValue = impactValue;
		this.textStyle = textStyle;
		this.spriteId = spriteId;
	}

	public class_2960 getSpriteId() {
		return spriteId;
	}

	public int getImpactValue() {
		return impactValue;
	}
	
	public String getTranslationKey() {
		return translationKey;
	}
	
	public class_124 getTextStyle() {
		return textStyle;
	}
	
	public class_5250 getTextComponent() {
		return class_2561.method_43471(getTranslationKey()).method_27692(getTextStyle());
	}
	
	public static Impact getByValue(int impactValue) {
		return Impact.values()[impactValue];
	}
}
