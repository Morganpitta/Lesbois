package io.github.apace100.origins.entity;

import io.github.apace100.origins.registry.ModEntities;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_239;
import net.minecraft.class_2398;
import net.minecraft.class_3222;
import net.minecraft.class_3857;
import java.util.Set;

public class EnderianPearlEntity extends class_3857 {

   public EnderianPearlEntity(class_1299<? extends class_3857> entityType, class_1937 world) {
      super(entityType, world);
   }

   public EnderianPearlEntity(class_1937 world, class_1309 owner) {
      super(ModEntities.ENDERIAN_PEARL, owner, world);
   }

   @Environment(EnvType.CLIENT)
   public EnderianPearlEntity(class_1937 world, double x, double y, double z) {
      super(ModEntities.ENDERIAN_PEARL, x, y, z, world);
   }

   protected class_1792 method_16942() {
      return class_1802.field_8634;
   }

   protected void method_7488(class_239 hitResult) {
      super.method_7488(hitResult);
      class_1297 entity = this.method_24921();

      for(int i = 0; i < 32; ++i) {
         this.method_37908().method_8406(class_2398.field_11214, this.method_23317(), this.method_23318() + this.field_5974.method_43058() * 2.0D, this.method_23321(), this.field_5974.method_43059(), 0.0D, this.field_5974.method_43059());
      }

      if (!this.method_37908().field_9236 && !this.method_31481()) {
         if (entity instanceof class_3222 serverPlayerEntity) {
             if (serverPlayerEntity.field_13987.method_48106() && serverPlayerEntity.method_37908() == this.method_37908() && !serverPlayerEntity.method_6113()) {

               if (entity.method_5765()) {
                  entity.method_5848();
               }

               entity.method_5859(this.method_23317(), this.method_23318(), this.method_23321());
               entity.field_6017 = 0.0F;
            }
         } else if (entity != null) {
            entity.method_5859(this.method_23317(), this.method_23318(), this.method_23321());
            entity.field_6017 = 0.0F;
         }

         this.method_31472();
      }

   }

   public void method_5773() {
      class_1297 entity = this.method_24921();
      if (entity instanceof class_1657 && !entity.method_5805()) {
         this.method_31472();
      } else {
         super.method_5773();
      }

   }

}
