package io.github.apace100.origins.util;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.apace100.origins.Origins;
import io.github.apace100.origins.origin.Origin;
import java.util.Optional;
import net.minecraft.class_2048;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_4558;
import net.minecraft.class_5258;

public class ChoseOriginCriterion extends class_4558<ChoseOriginCriterion.Conditions> {

    public static ChoseOriginCriterion INSTANCE = new ChoseOriginCriterion();
    public static final class_2960 ID = Origins.identifier("chose_origin");

    @Override
    public Codec<Conditions> method_54937() {
        return Conditions.CODEC;
    }

    public void trigger(class_3222 player, Origin origin) {
        this.method_22510(player, conditions -> conditions.matches(origin));
    }

    public record Conditions(Optional<class_5258> player, class_2960 originId) implements class_4558.class_8788 {

        public static final Codec<Conditions> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            class_2048.field_47250.optionalFieldOf("player").forGetter(Conditions::comp_2029),
            class_2960.field_25139.fieldOf("origin").forGetter(Conditions::originId)
        ).apply(instance, Conditions::new));

        @Override
        public Optional<class_5258> comp_2029() {
            return player;
        }

        public boolean matches(Origin origin) {
            return origin.getId().equals(originId);
        }

    }

}
