package io.github.apace100.origins.networking.packet.s2c;

import io.github.apace100.origins.Origins;
import io.netty.buffer.ByteBuf;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record OpenChooseOriginScreenS2CPacket(boolean showBackground) implements class_8710 {

    public static final class_9154<OpenChooseOriginScreenS2CPacket> PACKET_ID = new class_9154<>(Origins.identifier("s2c/open_origin_screen"));
    public static final class_9139<ByteBuf, OpenChooseOriginScreenS2CPacket> PACKET_CODEC = class_9135.field_48547.method_56432(OpenChooseOriginScreenS2CPacket::new, OpenChooseOriginScreenS2CPacket::showBackground);

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return PACKET_ID;
    }

}
