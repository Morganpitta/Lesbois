package io.github.apace100.origins.power.type;

import io.github.apace100.apoli.component.PowerHolderComponent;
import io.github.apace100.apoli.condition.EntityCondition;
import io.github.apace100.apoli.power.PowerConfiguration;
import io.github.apace100.apoli.power.type.PowerType;
import io.github.apace100.apoli.util.MiscUtil;
import io.github.apace100.origins.mixin.ActiveTargetGoalAccessor;
import io.github.apace100.origins.mixin.MobEntityAccessor;
import io.github.apace100.origins.mixin.TargetPredicateAccessor;
import org.jetbrains.annotations.NotNull;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Optional;
import java.util.Set;
import java.util.function.Predicate;
import net.minecraft.class_1301;
import net.minecraft.class_1309;
import net.minecraft.class_1314;
import net.minecraft.class_1338;
import net.minecraft.class_1355;
import net.minecraft.class_1400;
import net.minecraft.class_4135;

public class ScareCreepersPowerType extends PowerType {

    public ScareCreepersPowerType(Optional<EntityCondition> condition) {
        super(condition);
    }

    @Override
    public @NotNull PowerConfiguration<?> getConfig() {
        return OriginsPowerTypes.SCARE_CREEPERS;
    }

    public static void modifyGoals(class_1314 pathAwareEntity) {

        class_1355 targetSelector = ((MobEntityAccessor) pathAwareEntity).getTargetSelector();
        class_1355 goalSelector = ((MobEntityAccessor) pathAwareEntity).getGoalSelector();

        Iterator<class_4135> oldTargetPrioGoals = targetSelector.method_35115().iterator();
        Set<class_4135> newTargetPrioGoals = new HashSet<>();

        while (oldTargetPrioGoals.hasNext()) {

            class_4135 oldTargetPrioGoal = oldTargetPrioGoals.next();
            if (!(oldTargetPrioGoal.method_19058() instanceof ActiveTargetGoalAccessor oldTargetGoal)) {
                continue;
            }

            Predicate<class_1309> targetCondition = MiscUtil.combineAnd(((TargetPredicateAccessor) oldTargetGoal.getTargetPredicate()).getPredicate(), e -> !PowerHolderComponent.hasPowerType(e, ScareCreepersPowerType.class));
            class_4135 newTargetPrioGoal = new class_4135(oldTargetPrioGoal.method_19057(), new class_1400<>(pathAwareEntity, oldTargetGoal.getTargetClass(), oldTargetGoal.getReciprocalChance(), oldTargetGoal.getCheckVisibility(), oldTargetGoal.getCheckCanNavigate(), targetCondition));

            newTargetPrioGoals.add(newTargetPrioGoal);
            oldTargetPrioGoals.remove();

        }

        goalSelector.method_6277(3, new class_1338<>(pathAwareEntity, class_1309.class, e -> PowerHolderComponent.hasPowerType(e, ScareCreepersPowerType.class), 6.0F, 1.0D, 1.2D, class_1301.field_6156::test));
        newTargetPrioGoals.forEach(pg -> targetSelector.method_6277(pg.method_19057(), pg.method_19058()));

    }

}
