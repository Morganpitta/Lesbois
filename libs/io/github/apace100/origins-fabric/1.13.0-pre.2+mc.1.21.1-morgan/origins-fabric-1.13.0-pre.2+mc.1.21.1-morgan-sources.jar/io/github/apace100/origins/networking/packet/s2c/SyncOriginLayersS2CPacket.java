package io.github.apace100.origins.networking.packet.s2c;

import io.github.apace100.origins.Origins;
import io.github.apace100.origins.origin.OriginLayer;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record SyncOriginLayersS2CPacket(Map<class_2960, OriginLayer> layersById) implements class_8710 {

    public static final class_9154<SyncOriginLayersS2CPacket> PACKET_ID = new class_9154<>(Origins.identifier("s2c/sync_origin_layer_registry"));
    public static final class_9139<class_9129, SyncOriginLayersS2CPacket> PACKET_CODEC = class_9139.method_56438(SyncOriginLayersS2CPacket::write, SyncOriginLayersS2CPacket::read);

    public static SyncOriginLayersS2CPacket read(class_9129 buf) {

        Map<class_2960, OriginLayer> layersById = new HashMap<>();
        int count = buf.method_10816();

        for (int i = 0; i < count; i++) {

            try {
                OriginLayer layer = OriginLayer.DATA_TYPE.receive(buf);
                layersById.put(layer.getId(), layer);
            }

            catch (Exception e) {
                Origins.LOGGER.error(e);
                throw e;
            }

        }

        return new SyncOriginLayersS2CPacket(layersById);

    }

    public void write(class_9129 buf) {

        Collection<OriginLayer> layers = layersById.values();

        buf.method_10804(layers.size());
        layers.forEach(layer -> OriginLayer.DATA_TYPE.send(buf, layer));

    }

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return PACKET_ID;
    }

}
