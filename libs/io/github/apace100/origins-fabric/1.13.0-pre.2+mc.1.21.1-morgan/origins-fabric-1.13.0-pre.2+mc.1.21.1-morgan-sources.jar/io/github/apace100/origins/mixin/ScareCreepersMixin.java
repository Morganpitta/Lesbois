package io.github.apace100.origins.mixin;


import io.github.apace100.origins.power.type.ScareCreepersPowerType;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1548;
import net.minecraft.class_1937;
import net.minecraft.class_8152;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1308.class)
public abstract class ScareCreepersMixin extends class_1309 implements class_8152 {

    private ScareCreepersMixin(class_1299<? extends class_1309> entityType, class_1937 world) {
        super(entityType, world);
    }

    @Inject(method = "<init>", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/mob/MobEntity;initGoals()V", shift = At.Shift.AFTER))
    private void origins$modifyGoals(class_1299<?> entityType, class_1937 world, CallbackInfo ci) {

        if ((class_1308) (Object) this instanceof class_1548 thisAsCreeper) {
            ScareCreepersPowerType.modifyGoals(thisAsCreeper);
        }

    }

}
