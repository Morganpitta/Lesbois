package io.github.apace100.origins.content;

import io.github.apace100.origins.component.item.ItemOriginsComponent;
import io.github.apace100.origins.registry.ModDataComponentTypes;
import net.minecraft.class_1792;
import net.minecraft.class_1814;
import net.minecraft.util.*;

public class OrbOfOriginItem extends class_1792 {

    public OrbOfOriginItem() {
        this(new class_1793()
            .method_7889(1)
            .method_7894(class_1814.field_8903)
            .method_57349(ModDataComponentTypes.ORIGIN, ItemOriginsComponent.DEFAULT));
    }

    public OrbOfOriginItem(class_1793 settings) {
        super(settings);
    }

}
