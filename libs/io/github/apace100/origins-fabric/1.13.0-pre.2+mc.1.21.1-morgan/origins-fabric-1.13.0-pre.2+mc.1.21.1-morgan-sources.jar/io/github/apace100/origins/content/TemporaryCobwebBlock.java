package io.github.apace100.origins.content;

import net.minecraft.block.*;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2560;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3726;
import net.minecraft.class_4970;
import net.minecraft.class_5819;

public class TemporaryCobwebBlock extends class_2560 {

	public TemporaryCobwebBlock(class_4970.class_2251 settings) {
		super(settings);
	}

	@Override
	public void method_9588(class_2680 state, class_3218 world, class_2338 pos, class_5819 random) {
		if(!world.field_9236) {
			world.method_8501(pos, class_2246.field_10124.method_9564());
		}
	}

	@Override
	public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
		return class_259.method_1073();
	}

	@Override
	public class_265 method_9549(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
		return class_259.method_1073();
	}

	@Override
	public void method_9615(class_2680 state, class_1937 worldIn, class_2338 pos, class_2680 oldState, boolean isMoving) {
		worldIn.method_39279(pos, this, 60);
		super.method_9615(state, worldIn, pos, oldState, isMoving);
	}

}
