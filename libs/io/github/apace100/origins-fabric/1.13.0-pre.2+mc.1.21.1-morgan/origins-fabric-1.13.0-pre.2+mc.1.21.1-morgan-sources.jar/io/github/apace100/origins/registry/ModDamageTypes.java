package io.github.apace100.origins.registry;

import io.github.apace100.origins.Origins;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import net.minecraft.class_8110;

public class ModDamageTypes {

    public static final class_5321<class_8110> NO_WATER_FOR_GILLS = class_5321.method_29179(class_7924.field_42534, Origins.identifier("no_water_for_gills"));

}
