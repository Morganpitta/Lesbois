package io.github.apace100.origins.command.argument;

import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.DynamicCommandExceptionType;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import io.github.apace100.origins.origin.OriginLayer;
import io.github.apace100.origins.origin.OriginLayerManager;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_2172;
import net.minecraft.class_2561;
import net.minecraft.class_2960;

public class OriginLayerArgumentType implements ArgumentType<class_2960> {

   public static final DynamicCommandExceptionType LAYER_NOT_FOUND = new DynamicCommandExceptionType(
       o -> class_2561.method_54159("commands.origin.layer_not_found", o)
   );

   public static OriginLayerArgumentType layer() {
      return new OriginLayerArgumentType();
   }

   public static <S> OriginLayer getLayer(CommandContext<S> context, String argumentName) throws CommandSyntaxException {
      class_2960 id = context.getArgument(argumentName, class_2960.class);
      return OriginLayerManager.getResult(id)
          .result()
          .filter(OriginLayer::isEnabled)
          .orElseThrow(() -> LAYER_NOT_FOUND.create(id));
   }

   @Override
   public class_2960 parse(StringReader reader) throws CommandSyntaxException {
      return class_2960.method_58274(reader);
   }

   @Override
   public <S> CompletableFuture<Suggestions> listSuggestions(CommandContext<S> context, SuggestionsBuilder builder) {
      return class_2172.method_9257(OriginLayerManager.values().stream().filter(OriginLayer::isEnabled).map(OriginLayer::getId), builder);
   }

}
