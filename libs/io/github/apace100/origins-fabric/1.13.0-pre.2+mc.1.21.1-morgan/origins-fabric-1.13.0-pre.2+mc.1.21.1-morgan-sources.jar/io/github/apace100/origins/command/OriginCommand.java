package io.github.apace100.origins.command;

import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.tree.CommandNode;
import com.mojang.brigadier.tree.LiteralCommandNode;
import io.github.apace100.origins.Origins;
import io.github.apace100.origins.command.argument.OriginLayerArgumentType;
import io.github.apace100.origins.command.argument.OriginArgumentType;
import io.github.apace100.origins.component.OriginComponent;
import io.github.apace100.origins.networking.packet.s2c.OpenChooseOriginScreenS2CPacket;
import io.github.apace100.origins.origin.*;
import io.github.apace100.origins.registry.ModComponents;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_2168;
import net.minecraft.class_2186;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_5819;
import java.util.*;
import java.util.concurrent.atomic.AtomicReference;

import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

public class OriginCommand {

	public static void register(CommandNode<class_2168> baseNode) {

		//	The main node of the command
		var originNode = method_9247("origin")
			.requires(source -> source.method_9259(2))
			.build();

		//	Add the sub-nodes as children of the main node
		originNode.addChild(SetNode.get());
		originNode.addChild(HasNode.get());
		originNode.addChild(GetNode.get());
		originNode.addChild(GuiNode.get());
		originNode.addChild(RandomNode.get());

		//	Add the main node as a child of the main node
		baseNode.addChild(originNode);

	}

	public static final class SetNode {

		public static CommandNode<class_2168> get() {
			return method_9247("set")
				.then(method_9244("targets", class_2186.method_9308())
					.then(method_9244("layer", OriginLayerArgumentType.layer())
						.then(method_9244("origin", OriginArgumentType.origin())
							.executes(SetNode::execute)))).build();
		}

		public static int execute(CommandContext<class_2168> context) throws CommandSyntaxException {

			List<class_3222> targets = new ObjectArrayList<>(class_2186.method_9312(context, "targets"));

			OriginLayer layer = OriginLayerArgumentType.getLayer(context, "layer");
			Origin origin = OriginArgumentType.getOrigin(context, "origin");

			class_2168 source = context.getSource();
			int processedTargets = 0;

			if (origin.equals(Origin.EMPTY) || layer.getOrigins().contains(origin.getId())) {

				for (class_3222 target : targets) {

					OriginComponent originComponent = ModComponents.ORIGIN.get(target);
					boolean hadOriginBefore = originComponent.hadOriginBefore();

					originComponent.setOrigin(layer, origin);
					originComponent.sync();

					OriginComponent.partialOnChosen(target, hadOriginBefore, origin);
					processedTargets++;

				}

				if (processedTargets == 1) {
					source.method_9226(() -> class_2561.method_43469("commands.origin.set.success.single", targets.getFirst().method_5477(), layer.getName(), origin.getName()), true);
				}

				else {
					int finalProcessedTargets = processedTargets;
					source.method_9226(() -> class_2561.method_43469("commands.origin.set.success.multiple", finalProcessedTargets, layer.getName(), origin.getName()), true);
				}

			}

			else {
				source.method_9213(class_2561.method_54159("commands.origin.unregistered_in_layer", origin.getId(), layer.getId()));
			}

			return processedTargets;

		}

	}

	public static final class HasNode {

		public static CommandNode<class_2168> get() {
			return method_9247("has")
				.then(method_9244("targets", class_2186.method_9308())
					.then(method_9244("layer", OriginLayerArgumentType.layer())
						.then(method_9244("origin", OriginArgumentType.origin())
							.executes(HasNode::execute)))).build();
		}

		public static int execute(CommandContext<class_2168> context) throws CommandSyntaxException {

			List<class_3222> targets = new ObjectArrayList<>(class_2186.method_9312(context, "targets"));

			OriginLayer layer = OriginLayerArgumentType.getLayer(context, "layer");
			Origin origin = OriginArgumentType.getOrigin(context, "origin");

			class_2168 source = context.getSource();
			int processedTargets = 0;

			if (origin.equals(Origin.EMPTY) || layer.getOrigins().contains(origin.getId())) {

				for (class_3222 target : targets) {

					OriginComponent origincomponent = ModComponents.ORIGIN.get(target);

					if ((origin.equals(Origin.EMPTY) || origincomponent.hasOrigin(layer)) && origincomponent.getOrigin(layer).equals(origin)) {
						processedTargets++;
					}

				}

				if (processedTargets == 0) {
					source.method_9213(class_2561.method_43471("commands.execute.conditional.fail"));
				}

				else if (processedTargets == 1) {
					source.method_9226(() -> class_2561.method_43471("commands.execute.conditional.pass"), false);
				}

				else {
					int finalProcessedTargets = processedTargets;
					source.method_9226(() -> class_2561.method_43469("commands.execute.conditional.pass_count", finalProcessedTargets), false);
				}

			}

			else {
				source.method_9213(class_2561.method_54159("commands.origin.unregistered_in_layer", origin.getId(), layer.getId()));
			}

			return processedTargets;

		}

	}

	public static final class GetNode {

		public static CommandNode<class_2168> get() {
			return method_9247("get")
				.then(method_9244("target", class_2186.method_9305())
					.then(method_9244("layer", OriginLayerArgumentType.layer())
						.executes(GetNode::execute))).build();
		}

		public static int execute(CommandContext<class_2168> context) throws CommandSyntaxException {

			class_3222 target = class_2186.method_9315(context, "target");
			OriginLayer layer = OriginLayerArgumentType.getLayer(context, "layer");

			class_2168 source = context.getSource();
			OriginComponent originComponent = ModComponents.ORIGIN.get(target);

			Origin origin = originComponent.getOrigin(layer);
			source.method_9226(() -> class_2561.method_43469("commands.origin.get.result", target.method_5477(), layer.getName(), origin.getName(), origin.getId().toString()), false);

			return 1;

		}

	}

	public static final class GuiNode {

		public static CommandNode<class_2168> get() {
			return method_9247("gui")
				.executes(context -> openAll(context, true))
				.then(method_9244("targets", class_2186.method_9308())
					.executes(context -> openAll(context, false))
					.then(method_9244("layer", OriginLayerArgumentType.layer())
						.executes(GuiNode::openSpecific))).build();
		}

		public static int openAll(CommandContext<class_2168> context, boolean self) throws CommandSyntaxException {

			class_2168 source = context.getSource();
			Collection<class_3222> targets = self
				? List.of(source.method_9207())
				: class_2186.method_9312(context, "targets");

			for (class_3222 target : targets) {

				OriginComponent originComponent = ModComponents.ORIGIN.get(target);
				OriginLayerManager.values()
					.stream()
					.filter(OriginLayer::isEnabled)
					.forEach(layer -> originComponent.setOrigin(layer, Origin.EMPTY));

				boolean automaticallyAssigned = originComponent.checkAutoChoosingLayers(target, false);
				int optionCount = OriginLayerManager.getOriginOptionCount(target);

				originComponent.selectingOrigin(!automaticallyAssigned && optionCount > 0);
				originComponent.sync();

				if (originComponent.isSelectingOrigin()) {
					ServerPlayNetworking.send(target, new OpenChooseOriginScreenS2CPacket(false));
				}

			}

			source.method_9226(() -> class_2561.method_43469("commands.origin.gui.all", targets.size()), true);
			return targets.size();

		}

		public static int openSpecific(CommandContext<class_2168> context) throws CommandSyntaxException {

			Collection<class_3222> targets = class_2186.method_9312(context, "targets");
			OriginLayer layer = OriginLayerArgumentType.getLayer(context, "layer");

			for (class_3222 target : targets) {

				OriginComponent originComponent = ModComponents.ORIGIN.get(target);
				originComponent.setOrigin(layer, Origin.EMPTY);

				boolean automaticallyAssigned = originComponent.checkAutoChoosingLayers(target, false);
				int optionCount = layer.getOriginOptionCount(target);

				originComponent.selectingOrigin(!automaticallyAssigned && optionCount > 0);
				originComponent.sync();

				if (originComponent.isSelectingOrigin()) {
					ServerPlayNetworking.send(target, new OpenChooseOriginScreenS2CPacket(false));
				}

			}

			context.getSource().method_9226(() -> class_2561.method_43469("commands.origin.gui.layer", targets.size(), layer.getName()), true);
			return targets.size();

		}

	}

	public static final class RandomNode {

		public static CommandNode<class_2168> get() {
			return method_9247("random")
				.executes(context -> randomizeAll(context, true))
				.then(method_9244("targets", class_2186.method_9308())
					.executes(context -> randomizeAll(context, false))
					.then(method_9244("layer", OriginLayerArgumentType.layer())
						.executes(RandomNode::randomizeSpecific))).build();
		}

		public static int randomizeAll(CommandContext<class_2168> context, boolean self) throws CommandSyntaxException {

			class_2168 source = context.getSource();
			Collection<class_3222> targets = self
				? List.of(source.method_9207())
				: class_2186.method_9312(context, "targets");

			List<OriginLayer> layers = OriginLayerManager.values()
				.stream()
				.filter(OriginLayer::isRandomAllowed)
				.toList();

			for (class_3222 target : targets) {

				for (OriginLayer layer : layers) {
					setAndGetRandomOrigin(target, layer);
				}

			}

			source.method_9226(() -> class_2561.method_43469("commands.origin.random.all", targets.size(), layers.size()), true);
			return targets.size();

		}

		public static int randomizeSpecific(CommandContext<class_2168> context) throws CommandSyntaxException {

			List<class_3222> targets = new ObjectArrayList<>(class_2186.method_9312(context, "targets"));
			OriginLayer layer = OriginLayerArgumentType.getLayer(context, "layer");

			class_2168 source = context.getSource();
			AtomicReference<Origin> origin = new AtomicReference<>();

			if (layer.isRandomAllowed()) {

				for (class_3222 target : targets) {
					origin.set(setAndGetRandomOrigin(target, layer));
				}

				if (targets.size() > 1) {
					source.method_9226(() -> class_2561.method_43469("commands.origin.random.success.multiple", targets.size(), layer.getName()), true);
				}

				else {
					source.method_9226(() -> class_2561.method_43469("commands.origin.random.success.single", targets.getFirst().method_5477(), origin.get().getName(), layer.getName()), true);
				}

			}

			return targets.size();

		}

	}

	private static Origin setAndGetRandomOrigin(class_3222 target, OriginLayer layer) {

		List<Origin> origins = layer.getRandomOrigins(target)
			.stream()
			.filter(OriginManager::contains)
			.map(OriginManager::get)
			.toList();

		OriginComponent originComponent = ModComponents.ORIGIN.get(target);
		Origin origin = origins.get(class_5819.method_43047().method_43048(origins.size()));

		boolean hadOriginBefore = originComponent.hadOriginBefore();
		boolean hadAllOrigins = originComponent.hasAllOrigins();

		originComponent.setOrigin(layer, origin);
		originComponent.checkAutoChoosingLayers(target, false);

		originComponent.sync();

		if (originComponent.hasAllOrigins() && !hadAllOrigins) {
			OriginComponent.onChosen(target, hadOriginBefore);
		}

		Origins.LOGGER.info("Player {} was randomly assigned the origin {} for layer {}", target.method_5477().getString(), origin.getId(), layer.getId());
		return origin;

	}

}
