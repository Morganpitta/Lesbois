package io.github.apace100.origins;

import io.github.apace100.apoli.integration.PowerClearCallback;
import io.github.apace100.apoli.util.keybinding.KeyBindingUtil;
import io.github.apace100.origins.networking.ModPacketsS2C;
import io.github.apace100.origins.registry.ModBlocks;
import io.github.apace100.origins.registry.ModEntities;
import io.github.apace100.origins.screen.ViewOriginScreen;
import io.github.apace100.origins.util.PowerKeyManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.class_1921;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import net.minecraft.class_953;
import org.lwjgl.glfw.GLFW;

public class OriginsClient implements ClientModInitializer {

    public static class_304 primaryActiveKeyBinding;
    public static class_304 secondaryActiveKeyBinding;
    public static class_304 viewOriginKeyBinding;

    public static boolean isServerRunningOrigins = false;

    @Override
    @Environment(EnvType.CLIENT)
    public void onInitializeClient() {

        BlockRenderLayerMap.INSTANCE.putBlock(ModBlocks.TEMPORARY_COBWEB, class_1921.method_23581());
        EntityRendererRegistry.register(ModEntities.ENDERIAN_PEARL, class_953::new);

        ModPacketsS2C.register();

        primaryActiveKeyBinding = new class_304("key.origins.primary_active", class_3675.class_307.field_1668, GLFW.GLFW_KEY_G, "category." + Origins.MODID);
        secondaryActiveKeyBinding = new class_304("key.origins.secondary_active", class_3675.class_307.field_1668, GLFW.GLFW_KEY_UNKNOWN, "category." + Origins.MODID);
        viewOriginKeyBinding = new class_304("key.origins.view_origin", class_3675.class_307.field_1668, GLFW.GLFW_KEY_O, "category." + Origins.MODID);

        KeyBindingUtil.ALIASES.addAlias("primary", primaryActiveKeyBinding.method_1431());
        KeyBindingUtil.ALIASES.addAlias("secondary", secondaryActiveKeyBinding.method_1431());

        //  "none" is the default key used when no keybinding reference is specified in powers
        KeyBindingUtil.ALIASES.addAlias("none", primaryActiveKeyBinding.method_1431());

        KeyBindingHelper.registerKeyBinding(primaryActiveKeyBinding);
        KeyBindingHelper.registerKeyBinding(secondaryActiveKeyBinding);
        KeyBindingHelper.registerKeyBinding(viewOriginKeyBinding);

        ClientTickEvents.START_CLIENT_TICK.register(client -> {

            while (viewOriginKeyBinding.method_1436()) {

                if (!(client.field_1755 instanceof ViewOriginScreen)) {
                    client.method_1507(new ViewOriginScreen());
                }

            }

        });

        PowerClearCallback.EVENT.register(PowerKeyManager::clearCache);

    }
}
