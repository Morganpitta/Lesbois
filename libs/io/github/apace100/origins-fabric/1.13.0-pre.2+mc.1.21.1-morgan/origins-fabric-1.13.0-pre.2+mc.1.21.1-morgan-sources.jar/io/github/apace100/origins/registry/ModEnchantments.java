package io.github.apace100.origins.registry;

import io.github.apace100.origins.Origins;
import net.minecraft.class_1887;
import net.minecraft.class_5321;
import net.minecraft.class_7924;

public class ModEnchantments {

    public static final class_5321<class_1887> WATER_PROTECTION = class_5321.method_29179(class_7924.field_41265, Origins.identifier("water_protection"));

}
