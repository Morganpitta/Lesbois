package io.github.apace100.origins.registry;

import io.github.apace100.origins.Origins;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_6862;
import net.minecraft.class_7924;

public class ModTags {

    public static final class_6862<class_1792> MEAT = class_6862.method_40092(class_7924.field_41197, Origins.identifier("meat"));
    public static final class_6862<class_2248> UNPHASABLE = class_6862.method_40092(class_7924.field_41254, Origins.identifier("unphasable"));
    public static final class_6862<class_2248> NATURAL_STONE = class_6862.method_40092(class_7924.field_41254, Origins.identifier("natural_stone"));
    public static final class_6862<class_1792> RANGED_WEAPONS = class_6862.method_40092(class_7924.field_41197, Origins.identifier("ranged_weapons"));

    public static void register() {

    }

}
