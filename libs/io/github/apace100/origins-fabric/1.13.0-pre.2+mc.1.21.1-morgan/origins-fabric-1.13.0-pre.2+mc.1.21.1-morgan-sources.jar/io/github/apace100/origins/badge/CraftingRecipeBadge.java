package io.github.apace100.origins.badge;

import io.github.apace100.apoli.component.PowerHolderComponent;
import io.github.apace100.apoli.power.Power;
import io.github.apace100.apoli.power.type.ModifyCraftingPowerType;
import io.github.apace100.apoli.util.InventoryUtil;
import io.github.apace100.calio.data.SerializableData;
import io.github.apace100.origins.Origins;
import io.github.apace100.origins.screen.tooltip.CraftingRecipeTooltipComponent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1860;
import net.minecraft.class_1869;
import net.minecraft.class_2371;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_3532;
import net.minecraft.class_3955;
import net.minecraft.class_5455;
import net.minecraft.class_5630;
import net.minecraft.class_5684;
import net.minecraft.class_8786;
import net.minecraft.recipe.*;
import org.jetbrains.annotations.Nullable;

import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;

public record CraftingRecipeBadge(class_2960 spriteId,
                                  class_8786<class_3955> recipe,
                                  @Nullable class_2561 prefix,
                                  @Nullable class_2561 suffix) implements Badge {

    public CraftingRecipeBadge(SerializableData.Instance instance) {
        this(instance.getId("sprite"),
            instance.get("recipe"),
            instance.get("prefix"),
            instance.get("suffix"));
    }

    @Override
    public boolean hasTooltip() {
        return true;
    }

    public class_2371<class_1799> peekInputs(float time) {

        class_2371<class_1799> inputs = class_2371.method_10213(9, class_1799.field_8037);
        List<class_1856> ingredients = this.recipe.comp_1933().method_8117();

        int seed = class_3532.method_15375(time / 30);
        for (int index = 0; index < ingredients.size(); index++) {

            class_1799[] stacks = ingredients.get(index).method_8105();
            if (stacks.length > 0) {
                inputs.set(index, stacks[seed % stacks.length]);
            }

        }

        return inputs;

    }

    @Environment(EnvType.CLIENT)
    @Override
    public List<class_5684> getTooltipComponents(Power power, int widthLimit, float time, class_327 textRenderer) {

        class_310 client = class_310.method_1551();
        List<class_5684> tooltips = new LinkedList<>();

        if (client.field_1687 == null) {
            Origins.LOGGER.warn("Could not construct crafting recipe badge, as world was null!");
            return tooltips;
        }

        int recipeWidth = (class_1860<?>) recipe.comp_1933() instanceof class_1869 shapedRecipe ? shapedRecipe.method_8150() : 3;

        class_5455 registryManager = client.field_1687.method_30349();
        class_5630 outputStackReference = InventoryUtil.createStackReference(recipe.comp_1933().method_8110(registryManager));

        PowerHolderComponent.getPowerTypes(client.field_1724, ModifyCraftingPowerType.class)
            .stream()
            .filter(p -> p.doesApply(recipe.comp_1932(), outputStackReference.method_32327()))
            .max(Comparator.comparing(ModifyCraftingPowerType::getPriority))
            .ifPresent(p -> p.getNewResult(outputStackReference));
        CraftingRecipeTooltipComponent recipeTooltip = new CraftingRecipeTooltipComponent(recipeWidth, this.peekInputs(time), outputStackReference.method_32327());

        if (client.field_1690.field_1827) {

            class_2561 recipeIdText = class_2561.method_43470(recipe.comp_1932().toString()).method_27692(class_124.field_1063);
            widthLimit = Math.max(130, textRenderer.method_27525(recipeIdText));

            if (prefix != null) {
                TooltipBadge.addLines(tooltips, prefix, textRenderer, widthLimit);
            }

            tooltips.add(recipeTooltip);
            if (suffix != null) {
                TooltipBadge.addLines(tooltips, suffix, textRenderer, widthLimit);
            }

            TooltipBadge.addLines(tooltips, recipeIdText, textRenderer, widthLimit);

        } else {

            widthLimit = 130;
            if (prefix != null) {
                TooltipBadge.addLines(tooltips, prefix, textRenderer, widthLimit);
            }

            tooltips.add(recipeTooltip);
            if (suffix != null) {
                TooltipBadge.addLines(tooltips, suffix, textRenderer, widthLimit);
            }

        }

        return tooltips;

    }

    @Override
    public SerializableData.Instance toData(SerializableData.Instance instance) {
        instance.set("sprite", spriteId);
        instance.set("recipe", recipe);
        instance.set("prefix", prefix);
        instance.set("suffix", suffix);
        return instance;
    }

    @Override
    public BadgeFactory getBadgeFactory() {
        return BadgeFactories.CRAFTING_RECIPE;
    }

}
