package io.github.apace100.origins.networking.packet.s2c;

import io.github.apace100.origins.Origins;
import io.github.apace100.origins.badge.Badge;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record SyncBadgesS2CPacket(Map<class_2960, List<Badge>> badgesById) implements class_8710 {

    public static final class_9154<SyncBadgesS2CPacket> PACKET_ID = new class_9154<>(Origins.identifier("s2c/sync_badge_registry"));
    public static final class_9139<class_9129, SyncBadgesS2CPacket> PACKET_CODEC = class_9139.method_56438(SyncBadgesS2CPacket::write, SyncBadgesS2CPacket::read);

    public static SyncBadgesS2CPacket read(class_9129 buf) {

        Map<class_2960, List<Badge>> badgesById = new HashMap<>();
        int entriesCount = buf.method_10816();

        for (int i = 0; i < entriesCount; i++) {

            class_2960 id = buf.method_10810();
            int badgesCount = buf.method_10816();

            for (int j = 0; j < badgesCount; j++) {
                badgesById
                    .computeIfAbsent(id, k -> new LinkedList<>())
                    .add(Badge.receive(buf));
            }

        }

        return new SyncBadgesS2CPacket(badgesById);

    }

    public void write(class_9129 buf) {

        buf.method_10804(badgesById.size());
        for (Map.Entry<class_2960, List<Badge>> entry : badgesById.entrySet()) {

            class_2960 id = entry.getKey();
            List<Badge> badges = entry.getValue();

            buf.method_10812(id);
            buf.method_10804(badges.size());

            for (Badge badge : badges) {
                badge.send(buf);
            }

        }

    }

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return PACKET_ID;
    }

}
