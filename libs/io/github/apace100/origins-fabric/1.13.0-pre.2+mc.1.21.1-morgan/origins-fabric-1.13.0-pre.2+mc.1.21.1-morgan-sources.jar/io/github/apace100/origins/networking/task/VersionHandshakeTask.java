package io.github.apace100.origins.networking.task;

import io.github.apace100.origins.networking.packet.VersionHandshakePacket;
import net.fabricmc.fabric.api.networking.v1.ServerConfigurationNetworking;
import net.minecraft.class_2596;
import net.minecraft.class_8605;
import java.util.function.Consumer;

public record VersionHandshakeTask(int[] semver) implements class_8605 {

    public static final class_8605.class_8606 KEY = new class_8605.class_8606("origins:handshake/version");

    @Override
    public void method_52376(Consumer<class_2596<?>> sender) {
        sender.accept(ServerConfigurationNetworking.createS2CPacket(new VersionHandshakePacket(semver)));
    }

    @Override
    public class_8606 method_52375() {
        return KEY;
    }

}
