package io.github.apace100.origins.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.mojang.authlib.GameProfile;
import io.github.apace100.apoli.component.PowerHolderComponent;
import io.github.apace100.origins.power.type.WaterVisionPowerType;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_638;
import net.minecraft.class_742;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Environment(EnvType.CLIENT)
@Mixin(class_746.class)
public abstract class WaterVisionMixin extends class_742 {

    private WaterVisionMixin(class_638 world, GameProfile profile) {
        super(world, profile);
    }

    @ModifyExpressionValue(method = "getUnderwaterVisibility", at = @At(value = "FIELD", target = "Lnet/minecraft/client/network/ClientPlayerEntity;underwaterVisibilityTicks:I", ordinal = 0))
    private int origins$ignoreVisibilityDelay(int original) {
        return !PowerHolderComponent.hasPowerType(this, WaterVisionPowerType.class)
            ? original
            : 1000;
    }

}
