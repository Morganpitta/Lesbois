package io.github.apace100.origins.power.type;

import io.github.apace100.apoli.component.PowerHolderComponent;
import io.github.apace100.apoli.condition.EntityCondition;
import io.github.apace100.apoli.mixin.EntityAccessor;
import io.github.apace100.apoli.power.PowerConfiguration;
import io.github.apace100.apoli.power.type.PowerType;
import io.github.apace100.origins.mixin.LivingEntityAccessor;
import io.github.apace100.origins.registry.ModDamageTypes;
import org.jetbrains.annotations.NotNull;

import java.util.Optional;
import net.minecraft.class_1294;
import net.minecraft.class_1309;
import net.minecraft.class_2398;
import net.minecraft.class_3486;

public class WaterBreathingPowerType extends PowerType {

    public WaterBreathingPowerType(Optional<EntityCondition> condition) {
        super(condition);
    }

    @Override
    public @NotNull PowerConfiguration<?> getConfig() {
        return OriginsPowerTypes.WATER_BREATHING;
    }

    public static boolean shouldDrown(class_1309 entity) {
        return !entity.method_5777(class_3486.field_15517)
            && !entity.method_6059(class_1294.field_5923)
            && !entity.method_6059(class_1294.field_5927);
    }

    public static void tick(class_1309 entity) {

        if (!PowerHolderComponent.hasPowerType(entity, WaterBreathingPowerType.class)) {
            return;
        }

        LivingEntityAccessor entityAccess = (LivingEntityAccessor) entity;
        if (WaterBreathingPowerType.shouldDrown(entity)) {

            int landGain = entityAccess.callGetNextAirOnLand(0);
            int landLoss = entityAccess.callGetNextAirUnderwater(entity.method_5669());

            if (!((EntityAccessor) entity).callIsBeingRainedOn()) {

                entity.method_5855(landLoss - landGain);
                if (entity.method_5669() != -20) {
                    return;
                }

                entity.method_5855(0);
                entity.method_5643(entity.method_48923().method_48795(ModDamageTypes.NO_WATER_FOR_GILLS), 2.0F);

                for (int i = 0; i < 8; ++i) {

                    double dx = entity.method_59922().method_43058() - entity.method_59922().method_43058();
                    double dy = entity.method_59922().method_43058() - entity.method_59922().method_43058();
                    double dz = entity.method_59922().method_43058() - entity.method_59922().method_43058();

                    entity.method_37908().method_8406(class_2398.field_11247, entity.method_23322(0.5), entity.method_18381(entity.method_18376()), entity.method_23325(0.5), dx * 0.5, dy * 0.5 + 0.25, dz * 0.5);

                }

            }

            else {
                entity.method_5855(entity.method_5669() - landGain);
            }

        }

        else if (entity.method_5669() < entity.method_5748()) {
            entity.method_5855(entityAccess.callGetNextAirOnLand(entity.method_5669()));
        }

    }

}
