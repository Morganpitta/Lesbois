package io.github.apace100.origins.screen;

import io.github.apace100.origins.Origins;
import io.github.apace100.origins.OriginsClient;
import io.github.apace100.origins.origin.Origin;
import io.github.apace100.origins.origin.OriginLayer;
import io.github.apace100.origins.registry.ModComponents;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.Map;
import net.minecraft.class_1799;
import net.minecraft.class_1809;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_4185;
import net.minecraft.class_9296;
import net.minecraft.class_9334;

public class ViewOriginScreen extends OriginDisplayScreen {

	private final List<Entry> entries = new ObjectArrayList<>();
	private int index = 0;

	public ViewOriginScreen() {
		super(class_2561.method_43471(Origins.MODID + ".screen.view_origin"), false);
	}

	@Override
	protected void method_25426() {

		super.method_25426();

		assert field_22787 != null && field_22787.field_1724 != null : "Tried initializing the view origin screen with the client and its player unset!";
		assert windowWidget != null : "Tried initializing the view origin screen with the origin window unset!";

		Map<OriginLayer, Origin> origins = ModComponents.ORIGIN.get(field_22787.field_1724).getOrigins();
		this.entries.clear();

		origins.forEach((layer, origin) -> {

			if (!layer.isEnabled() || layer.isHidden() || (origin == Origin.EMPTY && layer.getOriginOptionCount(field_22787.field_1724) <= 0)) {
				return;
			}

			class_1799 icon = origin.getDisplayItem();
			this.entries.add(new Entry(layer, origin));

			if (icon.method_7909() instanceof class_1809 && !icon.method_57826(class_9334.field_49617)) {
				icon.method_57379(class_9334.field_49617, new class_9296(field_22787.field_1724.method_7334()));
			}

		});

		this.method_37063(class_4185.method_46430(class_2561.method_43471("origins.gui.close"), button -> field_22787.method_1507(null))
			.method_46433(windowWidget.method_46426() + windowWidget.method_25368() / 2 - 50, windowWidget.method_46427() + windowWidget.method_25364() + 5)
			.method_46437(100, 20)
			.method_46431());

		if (this.entries.isEmpty() || !OriginsClient.isServerRunningOrigins) {
			return;
		}

		this.entries.sort(Entry::compareTo);
		this.showCurrent();

		if (this.entries.size() <= 1) {
			return;
		}

		this.method_37063(class_4185.method_46430(class_2561.method_43470("<"), button -> this.previousLayer())
			.method_46433(windowWidget.method_46426() - 40, field_22790 / 2 - 10)
			.method_46437(20, 20)
			.method_46431());
		this.method_37063(class_4185.method_46430(class_2561.method_43470(">"), button -> this.nextLayer())
			.method_46433(windowWidget.method_46426() + windowWidget.method_25368() + 20, field_22790 / 2 - 10)
			.method_46437(20, 20)
			.method_46431());

	}

	@Override
	public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {

		super.method_25394(context, mouseX, mouseY, delta);

		if (entries.isEmpty()) {
			context.method_27534(field_22793, class_2561.method_43471(Origins.MODID + ".gui.view_origin." + (OriginsClient.isServerRunningOrigins ? "empty" : "not_installed")), field_22789 / 2, windowWidget.method_46427() + 48, -1);
		}

	}

	@Override
	public class_2561 method_25440() {
		return this.getCurrentLayer().getViewOriginTitle();
	}

	@Override
	protected OriginLayer getCurrentLayer() {
		return entries.get(index).layer();
	}

	@Override
	protected Origin getCurrentOrigin() {
		return entries.get(index).origin();
	}

	void showCurrent() {
		this.showCurrent(origin -> origin.getGuiMetadata().viewing());
	}

	void nextLayer() {
		this.index = class_3532.method_15387(index + 1, this.entries.size());
		this.showCurrent();
	}

	void previousLayer() {
		this.index = class_3532.method_15387(index - 1, this.entries.size());
		this.showCurrent();
	}

	private record Entry(OriginLayer layer, Origin origin) implements Comparable<Entry> {

		@Override
		public int compareTo(@NotNull ViewOriginScreen.Entry that) {
			return this.layer().compareTo(that.layer());
		}

	}

}
