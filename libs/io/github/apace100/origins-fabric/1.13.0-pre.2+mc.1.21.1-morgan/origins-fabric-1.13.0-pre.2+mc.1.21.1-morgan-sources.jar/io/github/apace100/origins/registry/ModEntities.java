package io.github.apace100.origins.registry;

import io.github.apace100.origins.Origins;
import io.github.apace100.origins.entity.EnderianPearlEntity;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_2378;
import net.minecraft.class_7923;

public class ModEntities {

    public static final class_1299<EnderianPearlEntity> ENDERIAN_PEARL;

    public static void register() {

    }

    static {
        ENDERIAN_PEARL = class_2378.method_10230(class_7923.field_41177, Origins.identifier("enderian_pearl"), class_1299.class_1300.<EnderianPearlEntity>method_5903(EnderianPearlEntity::new, class_1311.field_17715)
            .method_17687(0.25F, 0.25F)
            .method_27299(64)
            .method_27300(10)
            .build());
    }

}
