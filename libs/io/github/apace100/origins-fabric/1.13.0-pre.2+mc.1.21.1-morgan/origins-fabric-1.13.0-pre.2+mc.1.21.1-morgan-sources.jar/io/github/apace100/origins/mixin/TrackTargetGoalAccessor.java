package io.github.apace100.origins.mixin;

import net.minecraft.class_1405;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_1405.class)
public interface TrackTargetGoalAccessor {

    @Accessor
    boolean getCheckVisibility();

    @Accessor
    boolean getCheckCanNavigate();

}
