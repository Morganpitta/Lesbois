package io.github.apace100.origins.registry;

import io.github.apace100.origins.Origins;
import io.github.apace100.origins.content.TemporaryCobwebBlock;
import java.util.function.Supplier;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3620;
import net.minecraft.class_4970;
import net.minecraft.class_7923;

public class ModBlocks {

    public static final TemporaryCobwebBlock TEMPORARY_COBWEB = register("temporary_cobweb", false, () -> new TemporaryCobwebBlock(class_4970.class_2251.method_9637()
        .method_31710(class_3620.field_15979)
        .method_9632(4.0F)
        .method_29292()
        .method_9634()
        .method_51369()));

    public static void register() {

    }

    private static <B extends class_2248> B register(String name, boolean withBlockItem, Supplier<B> blockSupplier) {

        class_2960 blockId = Origins.identifier(name);
        B block = class_2378.method_10230(class_7923.field_41175, blockId, blockSupplier.get());

        if (withBlockItem) {
            class_2378.method_10230(class_7923.field_41178, blockId, new class_1747(block, new class_1792.class_1793()));
        }

        return block;

    }

}
