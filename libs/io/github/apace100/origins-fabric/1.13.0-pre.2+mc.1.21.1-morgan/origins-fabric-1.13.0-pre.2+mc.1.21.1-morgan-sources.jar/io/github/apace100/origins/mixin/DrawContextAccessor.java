package io.github.apace100.origins.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

import java.util.List;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_5684;
import net.minecraft.class_8000;

@Mixin(class_332.class)
public interface DrawContextAccessor {

    @Invoker
    void invokeDrawTooltip(class_327 textRenderer, List<class_5684> components, int x, int y, class_8000 positioner);
}
