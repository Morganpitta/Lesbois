package io.github.apace100.origins.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.sugar.Local;
import io.github.apace100.apoli.component.PowerHolderComponent;
import io.github.apace100.origins.power.type.ConduitPowerOnLandPowerType;
import net.minecraft.class_1657;
import net.minecraft.class_2597;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_2597.class)
public abstract class ConduitPowerOnLandMixin {

    @ModifyExpressionValue(method = "givePlayersEffects", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/player/PlayerEntity;isTouchingWaterOrRain()Z"))
    private static boolean origins$applyConduitPower(boolean original, @Local class_1657 player) {
        return original
            || PowerHolderComponent.hasPowerType(player, ConduitPowerOnLandPowerType.class);
    }

}
