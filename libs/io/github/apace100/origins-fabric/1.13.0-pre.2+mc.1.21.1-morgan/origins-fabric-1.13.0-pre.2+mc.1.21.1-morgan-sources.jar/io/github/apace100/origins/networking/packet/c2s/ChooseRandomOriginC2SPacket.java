package io.github.apace100.origins.networking.packet.c2s;

import io.github.apace100.origins.Origins;
import io.netty.buffer.ByteBuf;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

public record ChooseRandomOriginC2SPacket(class_2960 layerId) implements class_8710 {

    public static final class_9154<ChooseRandomOriginC2SPacket> PACKET_ID = new class_9154<>(Origins.identifier("c2s/choose_random_origin"));
    public static final class_9139<ByteBuf, ChooseRandomOriginC2SPacket> PACKET_CODEC = class_2960.field_48267.method_56432(ChooseRandomOriginC2SPacket::new, ChooseRandomOriginC2SPacket::layerId);

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return PACKET_ID;
    }

}
