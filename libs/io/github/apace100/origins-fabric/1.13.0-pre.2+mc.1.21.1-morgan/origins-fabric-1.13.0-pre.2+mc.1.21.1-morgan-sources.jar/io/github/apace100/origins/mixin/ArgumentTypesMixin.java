package io.github.apace100.origins.mixin;

import com.mojang.brigadier.arguments.ArgumentType;
import io.github.apace100.origins.Origins;
import io.github.apace100.origins.command.argument.OriginLayerArgumentType;
import net.minecraft.class_2314;
import net.minecraft.class_2316;
import net.minecraft.class_2319;
import net.minecraft.class_2378;
import io.github.apace100.origins.command.argument.OriginArgumentType;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_2316.class)
public abstract class ArgumentTypesMixin {
    @Shadow
    private static <A extends ArgumentType<?>, T extends class_2314.class_7217<A>> class_2314<A, T> register(class_2378<class_2314<?, ?>> registry, String string, Class<? extends A> clazz, class_2314<A, T> argumentSerializer) {
        throw new AssertionError("Mixins for basic functionality are fun.");
    }

    @Inject(method = "register(Lnet/minecraft/registry/Registry;)Lnet/minecraft/command/argument/serialize/ArgumentSerializer;", at = @At("RETURN"))
    private static void registerApoliArgumentTypes(class_2378<class_2314<?, ?>> registry, CallbackInfoReturnable<class_2314<?, ?>> cir) {
        register(registry, Origins.MODID + ":origin", OriginArgumentType.class, class_2319.method_41999(OriginArgumentType::origin));
        register(registry, Origins.MODID + ":layer", OriginLayerArgumentType.class, class_2319.method_41999(OriginLayerArgumentType::layer));
    }
}
