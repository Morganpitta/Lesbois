package io.github.apace100.origins.mixin;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import io.github.apace100.origins.component.item.ItemOriginsComponent;
import io.github.apace100.origins.registry.ModDataComponentTypes;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_3468;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_1792.class)
public abstract class ItemMixin {

    @ModifyReturnValue(method = "use", at = @At("RETURN"))
    private class_1271<class_1799> origins$selectItemOrigins(class_1271<class_1799> original, class_1937 world, class_1657 user, class_1268 hand) {

        if (original.method_5467() != class_1269.field_5811) {
            return original;
        }

        class_1799 stack = original.method_5466();
        ItemOriginsComponent itemOrigins = stack.method_57824(ModDataComponentTypes.ORIGIN);

        if (itemOrigins != null && itemOrigins.setOrigin(user)) {

            user.method_7259(class_3468.field_15372.method_14956((class_1792) (Object) this));
            stack.method_57008(1, user);

            return class_1271.method_22428(stack);

        }

        else {
            return original;
        }

    }

}
