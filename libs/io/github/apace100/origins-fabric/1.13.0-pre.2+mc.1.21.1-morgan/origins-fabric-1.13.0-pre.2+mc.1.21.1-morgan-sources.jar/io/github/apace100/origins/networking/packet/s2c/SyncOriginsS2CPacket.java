package io.github.apace100.origins.networking.packet.s2c;

import io.github.apace100.origins.Origins;
import io.github.apace100.origins.origin.Origin;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.util.Collection;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record SyncOriginsS2CPacket(Map<class_2960, Origin> originsById) implements class_8710 {

    public static final class_9154<SyncOriginsS2CPacket> PACKET_ID = new class_9154<>(Origins.identifier("s2c/sync_origin_registry"));
    public static final class_9139<class_9129, SyncOriginsS2CPacket> PACKET_CODEC = class_9139.method_56438(SyncOriginsS2CPacket::write, SyncOriginsS2CPacket::read);

    public static SyncOriginsS2CPacket read(class_9129 buf) {

        try {

            Collection<Origin> origins = new ObjectArrayList<>();
            int originsCount = buf.method_10816();

            for (int i = 0; i < originsCount; i++) {
                origins.add(Origin.DATA_TYPE.receive(buf));
            }

            return new SyncOriginsS2CPacket(origins
                .stream()
                .collect(Collectors.toMap(Origin::getId, Function.identity(), (oldOrigin, newOrigin) -> newOrigin, Object2ObjectOpenHashMap::new)));

        }

        catch (Exception e) {
            Origins.LOGGER.error(e.getMessage());
            throw e;
        }

    }

    public void write(class_9129 buf) {

        Collection<Origin> origins = this.originsById().values();
        buf.method_10804(origins.size());

        origins.forEach(origin -> Origin.DATA_TYPE.send(buf, origin));

    }

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return PACKET_ID;
    }

}
