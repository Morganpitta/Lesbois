package io.github.apace100.origins.networking.packet.c2s;

import io.github.apace100.origins.Origins;
import io.netty.buffer.ByteBuf;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

public record ChooseOriginC2SPacket(class_2960 layerId, class_2960 originId) implements class_8710 {

    public static final class_9154<ChooseOriginC2SPacket> PACKET_ID = new class_9154<>(Origins.identifier("c2s/choose_origin"));
    public static final class_9139<ByteBuf, ChooseOriginC2SPacket> PACKET_CODEC = class_9139.method_56435(
        class_2960.field_48267, ChooseOriginC2SPacket::layerId,
        class_2960.field_48267, ChooseOriginC2SPacket::originId,
        ChooseOriginC2SPacket::new
    );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return PACKET_ID;
    }

}
