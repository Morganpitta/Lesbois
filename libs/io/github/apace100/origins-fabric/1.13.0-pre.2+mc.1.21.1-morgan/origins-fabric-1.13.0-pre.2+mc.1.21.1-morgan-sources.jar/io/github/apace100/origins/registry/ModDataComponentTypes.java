package io.github.apace100.origins.registry;

import io.github.apace100.origins.Origins;
import io.github.apace100.origins.component.item.ItemOriginsComponent;
import net.minecraft.class_2378;
import net.minecraft.class_7923;
import net.minecraft.class_9331;

public class ModDataComponentTypes {

    public static final class_9331<ItemOriginsComponent> ORIGIN = class_9331.<ItemOriginsComponent>method_57873()
        .method_57881(ItemOriginsComponent.CODEC)
        .method_57882(ItemOriginsComponent.PACKET_CODEC)
        .method_57880();

    public static void register() {
        class_2378.method_10230(class_7923.field_49658, Origins.identifier("origin"), ORIGIN);
    }

}
