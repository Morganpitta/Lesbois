package io.github.apace100.origins.mixin;

import io.github.apace100.origins.Origins;
import io.github.apace100.origins.component.OriginComponent;
import io.github.apace100.origins.origin.Origin;
import io.github.apace100.origins.origin.OriginManager;
import io.github.apace100.origins.registry.ModComponents;
import net.minecraft.class_124;
import net.minecraft.class_167;
import net.minecraft.class_2561;
import net.minecraft.class_2985;
import net.minecraft.class_3222;
import net.minecraft.class_8779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_2985.class)
public abstract class OriginUpgradeMixin {

    @Shadow
    private class_3222 owner;

    @Shadow
    public abstract class_167 getProgress(class_8779 advancement);

    @Inject(method = "grantCriterion", at = @At(value = "INVOKE", target = "Lnet/minecraft/advancement/PlayerAdvancementTracker;endTrackingCompleted(Lnet/minecraft/advancement/AdvancementEntry;)V"))
    private void checkOriginUpgrade(class_8779 advancement, String criterionName, CallbackInfoReturnable<Boolean> cir) {

        class_167 progress = this.getProgress(advancement);
        if (!progress.method_740()) {
            return;
        }

        Origin.get(owner).forEach((originLayer, origin) -> origin.getUpgrade(advancement).ifPresent(originUpgrade -> {
            try {

                Origin upgradeTo = OriginManager.get(originUpgrade.upgradeToOrigin());
                OriginComponent component = ModComponents.ORIGIN.get(owner);

                component.setOrigin(originLayer, upgradeTo);
                component.sync();

                String announcement = originUpgrade.announcement();
                if (announcement != null) {
                    owner.method_7353(class_2561.method_43471(announcement).method_27692(class_124.field_1065), false);
                }

            } catch (Exception e) {
                Origins.LOGGER.error("Could not perform Origins upgrade from \"{}\" to \"{}\", as the upgrade origin did not exist!", origin.getId(), originUpgrade.upgradeToOrigin().toString());
            }
        }));

    }

}
