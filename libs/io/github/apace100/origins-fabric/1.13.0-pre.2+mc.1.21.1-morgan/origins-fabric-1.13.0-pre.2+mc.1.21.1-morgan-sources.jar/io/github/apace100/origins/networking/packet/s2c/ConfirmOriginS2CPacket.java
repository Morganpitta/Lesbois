package io.github.apace100.origins.networking.packet.s2c;

import io.github.apace100.origins.Origins;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

public record ConfirmOriginS2CPacket(class_2960 layerId, class_2960 originId) implements class_8710 {

    public static final class_9154<ConfirmOriginS2CPacket> PACKET_ID = new class_9154<>(Origins.identifier("s2c/confirm_origin"));
    public static final class_9139<class_2540, ConfirmOriginS2CPacket> PACKET_CODEC = class_9139.method_56435(
        class_2960.field_48267, ConfirmOriginS2CPacket::layerId,
        class_2960.field_48267, ConfirmOriginS2CPacket::originId,
        ConfirmOriginS2CPacket::new
    );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return PACKET_ID;
    }

}
