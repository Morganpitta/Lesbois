package io.github.apace100.origins.screen.widget;

import io.github.apace100.origins.Origins;
import io.github.apace100.origins.origin.Impact;
import io.github.apace100.origins.screen.TooltipDrawer;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_6382;

public final class ImpactWidget extends class_339 implements TooltipDrawer {

	private final Impact impact;

	public ImpactWidget(Impact impact, int x, int y) {
		super(x, y, 28, 8, class_2561.method_43471(Origins.MODID + ".gui.impact.impact").method_27693(": ").method_10852(impact.getTextComponent()));
		this.impact = impact;
	}

	@Override
	public void renderTooltip(class_327 textRenderer, class_332 context, int mouseX, int mouseY, float delta) {
		context.method_51438(textRenderer, this.method_25369(), mouseX, mouseY);
	}

	@Override
	protected void method_48579(class_332 context, int mouseX, int mouseY, float delta) {
		context.method_52706(impact.getSpriteId(), this.method_46426(), this.method_46427(), 28, 8);
	}

	@Override
	protected void method_47399(class_6382 builder) {

	}

}
