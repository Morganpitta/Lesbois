package io.github.apace100.origins.screen.widget;

import io.github.apace100.apoli.power.MultiplePower;
import io.github.apace100.apoli.power.Power;
import io.github.apace100.apoli.power.SubPower;
import io.github.apace100.apoli.util.TextAlignment;
import io.github.apace100.origins.badge.Badge;
import io.github.apace100.origins.badge.BadgeManager;
import io.github.apace100.origins.origin.Origin;
import io.github.apace100.origins.origin.OriginLayer;
import io.github.apace100.origins.origin.OriginManager;
import io.github.apace100.origins.screen.TooltipDrawer;
import io.github.apace100.origins.util.MiscUtilClient;
import it.unimi.dsi.fastutil.objects.ObjectAVLTreeSet;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import it.unimi.dsi.fastutil.objects.ObjectSortedSet;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_3532;
import net.minecraft.class_437;
import net.minecraft.class_5250;
import net.minecraft.class_5481;
import net.minecraft.class_6382;
import org.jetbrains.annotations.Nullable;
import org.lwjgl.glfw.GLFW;

import java.util.Collection;
import java.util.List;
import java.util.function.Function;

@Environment(EnvType.CLIENT)
public class OriginWindowWidget extends class_339 {

	private static final int LINE_HEIGHT = 11;

	private final class_327 textRenderer;
	private final List<TooltipDrawer> hoveredTooltips;

	private Origin.WindowTextures textures = Origin.WindowTextures.DEFAULT;
	private class_5250 randomDescription = class_2561.method_43473();

	@Nullable
	private Origin origin;
	@Nullable
	private OriginLayer layer;

	private boolean random;
	private boolean dragScrolling;

	private int scrollY;
	private int contentsHeight;

	public OriginWindowWidget(int x, int y, int width, int height, class_327 textRenderer) {
		super(x, y, width, height, class_2561.method_43473());
		this.textRenderer = textRenderer;
		this.hoveredTooltips = new ObjectArrayList<>();
	}

	@Override
	public boolean method_25402(double mouseX, double mouseY, int button) {

		if (!this.field_22763 || !this.field_22764) {
			return false;
		}

		boolean clicked = this.method_25405(mouseX, mouseY);
		this.dragScrolling = this.overflowing()
			&& this.method_25351(button)
			&& mouseX >= this.method_46426() + this.method_25368()
			&& mouseX <= this.method_46426() + this.method_25368() + this.getScrollerWidth()
			&& mouseY >= this.method_46427()
			&& mouseY <= this.method_46427() + this.method_25364();

		return clicked
			|| dragScrolling;

	}

	@Override
	public boolean method_25403(double mouseX, double mouseY, int button, double deltaX, double deltaY) {

		if (!this.field_22764 || !this.method_25370() || !this.dragScrolling) {
			return false;
		}

		if (mouseY < this.method_46427()) {
			this.setScrollY(0);
		}

		else if (mouseY > this.method_46427() + this.method_25364()) {
			this.setScrollY(this.getMaxScrollY());
		}

		else {

			int thumbHeight = this.getScrollBarThumbHeight();
			int scrolled = Math.max(1, this.getMaxScrollY() / (this.method_25364() - thumbHeight));

			this.setScrollY(this.getScrollY() + (int) deltaY * scrolled);

		}

		return true;

	}

	@Override
	public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {

		if (this.field_22764) {
			this.setScrollY(this.scrollY - (int) verticalAmount * this.getDeltaYPerScroll());
		}

		return this.field_22764;

	}

	@Override
	public void method_25357(double mouseX, double mouseY) {
		this.dragScrolling = false;
	}

	@Override
	public boolean method_25404(int keyCode, int scanCode, int modifiers) {

		boolean pressedUpArrow = keyCode == GLFW.GLFW_KEY_UP;
		boolean pressedDownArrow = keyCode == GLFW.GLFW_KEY_DOWN;

		if (this.method_25370() && (pressedUpArrow || pressedDownArrow)) {

			int prevScrollY = this.getScrollY();
			this.setScrollY(this.scrollY + (pressedUpArrow ? -1 : 1) * this.getDeltaYPerScroll());

			if (prevScrollY != this.getScrollY()) {
				return true;
			}

		}

		return super.method_25404(keyCode, scanCode, modifiers);

	}

	@Override
	protected void method_47399(class_6382 builder) {

	}

	@Override
	protected void method_48579(class_332 context, int mouseX, int mouseY, float delta) {

		if (!this.field_22764) {
			return;
		}

		this.contentsHeight = 0;
		this.hoveredTooltips.clear();

		//  Draw the window's background
		context.method_52706(textures.background(), this.method_46426(), this.method_46427(), this.method_25368(), this.method_25364());

		//  Draw the contents of the window
		context.method_44379(this.method_46426() + 1, this.method_46427() + 1, this.method_46426() + this.method_25368() + 1, this.method_46427() + this.method_25364() - 1);
		context.method_51448().method_22903();
		context.method_51448().method_46416(0, 0, 1);

		this.renderPowersAndBadges(context, mouseX, mouseY, delta);
		this.renderNameAndImpact(context, mouseX, mouseY, delta);

		context.method_51448().method_22909();
		context.method_44380();

		//  Draw the scrollbar at the side of the window
		if (this.overflowing()) {
			this.renderScroller(context);
		}

		//  Draw the border and the tooltips of the hovered elements
		context.method_52707(textures.border(), this.method_46426(), this.method_46427(), 2, this.method_25368(), this.method_25364());
		this.hoveredTooltips.forEach(tooltip -> tooltip.renderTooltip(textRenderer, context, mouseX, mouseY, delta));

	}

	public void show(@Nullable Origin origin, @Nullable OriginLayer layer, Function<Origin, Origin.WindowTextures> texturesGetter) {

		this.origin = origin;
		this.layer = layer;

		this.random = origin == Origin.RANDOM;

		this.randomDescription = class_2561.method_43473();
		this.scrollY = 0;

		if (layer == null || origin == null) {
			return;
		}

		ObjectSortedSet<Origin> randoms = new ObjectAVLTreeSet<>(Origin::compareTo);
		layer.getRandomOrigins(class_310.method_1551().field_1724).forEach(id -> randoms.add(OriginManager.get(id)));

		for (var random : randoms) {
			this.randomDescription.method_10852(class_2561.method_30163("\n")).method_27693("- ").method_10852(random.getName());
		}

		this.textures = texturesGetter.apply(origin);

	}

	protected void renderNameAndImpact(class_332 context, int mouseX, int mouseY, float delta) {

		if (origin == null) {
			return;
		}

		int x = this.method_46426();
		int y = this.method_46427() - this.getScrollY();

		class_1799 icon = origin.getDisplayItem();
		ImpactWidget impactWidget = new ImpactWidget(origin.getImpact(), (x + this.method_25368()) - 48, y + 19);

		int nameStartX = x + 40;
		int nameStartY = y + 18;
		int nameEndX = impactWidget.method_46426() - 2;
		int nameEndY = nameStartY + 9;

		context.method_52706(textures.namePlate(), x + 10, y + 10, this.method_25368() - 26, 26);
		MiscUtilClient.drawScrollingText(context, textRenderer, origin.getName(), TextAlignment.LEFT, nameStartX, nameStartY, nameEndX, nameEndY, 0xFFFFFF, true);

		impactWidget.method_48579(context, mouseX, mouseY, delta);
		context.method_51427(icon, x + 15, y + 15);

		if (impactWidget.method_25405(mouseX, mouseY) && context.method_58135(mouseX, mouseY)) {
			hoveredTooltips.add(impactWidget);
		}

	}

	protected void renderPowersAndBadges(class_332 context, int mouseX, int mouseY, float delta) {

		if (origin == null || layer == null) {
			return;
		}

		int x = this.method_46426() + 18;
		int y = (this.method_46427() + 45) - this.getScrollY();

		int widthLimit = this.method_25368() - 30;
		this.contentsHeight = this.method_46427() + 45;

		class_2561 description = origin == Origin.EMPTY && layer.getMissingDescription() != null
			? layer.getMissingDescription()
			: origin.getDescription();

		for (var line : textRenderer.method_1728(description, widthLimit)) {

			context.method_35720(textRenderer, line, x, y, 0xCCCCCC);

			y += LINE_HEIGHT;
			contentsHeight += LINE_HEIGHT;

		}

		if (random) {

			for (var line : textRenderer.method_1728(randomDescription, widthLimit)) {

				context.method_35720(textRenderer, line, x, y, 0xCCCCCC);

				y += LINE_HEIGHT;
				contentsHeight += LINE_HEIGHT;

			}

		}

		else {

			for (var power : origin.getPowers()) {

				if (power.isHidden()) {
					continue;
				}

				y += LINE_HEIGHT;
				contentsHeight += LINE_HEIGHT;

				List<class_5481> powerName = new ObjectArrayList<>(textRenderer.method_1728(power.getName().method_27692(class_124.field_1073), widthLimit));
				int powerNameWidth = textRenderer.method_30880(powerName.getLast());

				for (var powerNameLine : powerName) {

					context.method_35720(textRenderer, powerNameLine, x, y, 0xFFFFFF);

					y += LINE_HEIGHT;
					contentsHeight += LINE_HEIGHT;

				}

				y -= LINE_HEIGHT;
				contentsHeight -= LINE_HEIGHT;

				int badgeStartX = x + powerNameWidth + 4;
				int badgeEndX = x + (this.method_25368() - 6);

				int badgeOffsetX = 0;
				int badgeOffsetY = 0;

				for (var badgeWidget : this.getBadgeWidgets(power)) {

					int badgeX = badgeStartX + (badgeOffsetX * 10);
					int badgeY = (y - 1) + (badgeOffsetY * 10);

					if (badgeX >= badgeEndX) {

						badgeOffsetX = 0;
						badgeOffsetY++;

						badgeX = badgeStartX = x;
						badgeY = (y - 1) + (badgeOffsetY * 10);

					}

					badgeWidget.method_48229(badgeX, badgeY);
					badgeWidget.method_25394(context, mouseX, mouseY, delta);

					badgeOffsetX++;

					if (badgeWidget.hasTooltip() && badgeWidget.method_25405(mouseX, mouseY) && context.method_58135(mouseX, mouseY)) {
						hoveredTooltips.add(badgeWidget);
					}

				}

				int badgeOffset = Math.max(badgeOffsetY, 1) * 10;

				y += badgeOffset;
				contentsHeight += badgeOffset;

				for (var powerDescriptionLine : textRenderer.method_1728(power.getDescription(), widthLimit)) {

					context.method_35720(textRenderer, powerDescriptionLine, x, y, 0xCCCCCC);

					y += LINE_HEIGHT;
					contentsHeight += LINE_HEIGHT;

				}

			}

		}

	}

	protected Collection<BadgeWidget> getBadgeWidgets(Power power) {

		if (!BadgeManager.hasPowerBadges(power)) {

			if (power instanceof MultiplePower multiplePower) {

				List<BadgeWidget> widgets = new ObjectArrayList<>();
				for (var subPower : multiplePower.getSubPowers()) {

					for (var badge : BadgeManager.getPowerBadges(subPower.getId())) {
						widgets.add(new BadgeWidget(subPower, badge, 0, 0));
					}

				}

				return widgets;

			}

			else {
				return List.of();
			}

		}

		else {

			List<BadgeWidget> widgets = new ObjectArrayList<>();
			for (var badge : BadgeManager.getPowerBadges(power.getId())) {
				widgets.add(new BadgeWidget(power, badge, 0, 0));
			}

			return widgets;

		}

	}

	protected boolean overflowing() {
		return this.getContentsHeight() > this.method_25364()
			&& this.getMaxScrollY() > 0;
	}

	protected int getContentsHeightWithPadding() {
		return this.getContentsHeight() + this.getContentsPadding();
	}

	protected int getContentsPadding() {
		return 8;
	}

	protected int getScrollBarThumbHeight() {
		return class_3532.method_15340((int) ((float) (this.method_25364() * this.method_25364()) / (float) (this.getContentsHeightWithPadding())), 27, this.method_25364());
	}

	protected int getScrollerWidth() {
		return 8;
	}

	protected int getDeltaYPerScroll() {
		return class_437.method_25442() ? 4 : 12;
	}

	protected int getContentsHeight() {
		return contentsHeight;
	}

	protected int getMaxScrollY() {
		return Math.max(0, (this.getContentsHeightWithPadding() - (this.field_22759 - this.getContentsPadding())) - this.method_46427());
	}

	protected int getScrollY() {
		return scrollY;
	}

	protected void setScrollY(int scrollY) {
		this.scrollY = class_3532.method_15340(scrollY, 0, this.getMaxScrollY());
	}

	protected void renderScroller(class_332 context) {

		int width = this.getScrollerWidth();
		int height = this.getScrollBarThumbHeight();
		int x = this.method_46426() + this.method_25368();
		int y = Math.max(this.method_46427(), ((this.getScrollY() * (this.method_25364() - height)) / this.getMaxScrollY()) + this.method_46427());

		context.method_52706(textures.scroller().slot(), x, this.method_46427(), width, this.method_25364());
		context.method_52706(dragScrolling ? textures.scroller().pressed() : textures.scroller().unpressed(),  x, y, width, height);

	}

}
