package io.github.apace100.origins.command.argument;

import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.DynamicCommandExceptionType;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import io.github.apace100.origins.origin.*;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Stream;
import net.minecraft.class_2172;
import net.minecraft.class_2561;
import net.minecraft.class_2960;

public class OriginArgumentType implements ArgumentType<class_2960> {

   public static final DynamicCommandExceptionType ORIGIN_NOT_FOUND = new DynamicCommandExceptionType(
       o -> class_2561.method_43469("commands.origin.origin_not_found", o)
   );

   public static OriginArgumentType origin() {
      return new OriginArgumentType();
   }

   public static <S> Origin getOrigin(CommandContext<S> context, String argumentName) throws CommandSyntaxException {
      class_2960 id = context.getArgument(argumentName, class_2960.class);
      return OriginManager
          .getOptional(id)
          .orElseThrow(() -> ORIGIN_NOT_FOUND.create(id));
   }

   @Override
   public class_2960 parse(StringReader reader) throws CommandSyntaxException {
      return class_2960.method_58274(reader);
   }

   @Override
   public <S> CompletableFuture<Suggestions> listSuggestions(CommandContext<S> context, SuggestionsBuilder builder) {

      try {

         OriginLayer layer = OriginLayerArgumentType.getLayer(context, "layer");
         Stream.Builder<class_2960> origins = Stream.builder();

         origins.add(Origin.EMPTY.getId());
         layer.getOrigins().forEach(origins);

         return class_2172.method_9257(origins.build(), builder);

      }

      catch (Exception e) {
         return class_2172.method_9257(Stream.of(), builder);
      }

   }

}
