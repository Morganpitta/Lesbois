package io.github.apace100.origins.screen.tooltip;

import io.github.apace100.origins.Origins;
import net.minecraft.class_1799;
import net.minecraft.class_2371;
import net.minecraft.class_2960;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_5684;

/**A {@link class_5684} used for {@link io.github.apace100.origins.badge.CraftingRecipeBadge}
 * Draws a snapshot of a 3x3 crafting recipe in the tooltip*/
public class CraftingRecipeTooltipComponent implements class_5684 {

    private static final class_2960 TEXTURE = Origins.identifier("textures/gui/tooltip/recipe_tooltip.png");

    private final class_2371<class_1799> inputs;
    private final class_1799 output;

    private final int recipeWidth;

    public CraftingRecipeTooltipComponent(int recipeWidth, class_2371<class_1799> inputs, class_1799 output) {
        this.recipeWidth = recipeWidth;
        this.inputs = inputs;
        this.output = output;
    }

    @Override
    public int method_32661() {
        return 68;
    }

    @Override
    public int method_32664(class_327 textRenderer) {
        return 130;
    }

    @Override
    public void method_32666(class_327 textRenderer, int x, int y, class_332 context) {
        this.drawBackground(context, x, y);
        for(int column = 0; column < 3; ++column) {
            for(int row = 0; row < 3; ++row) {
                int index = column + row * recipeWidth;
                int slotX = x + 8 + column * 18;
                int slotY = y + 8 + row * 18;
                class_1799 stack = column >= recipeWidth ? class_1799.field_8037 : inputs.get(index);
                context.method_51427(stack, slotX, slotY);
                context.method_51431(textRenderer, stack, slotX, slotY);
            }
        }
        context.method_51427(output, x + 101, y + 25);
        context.method_51431(textRenderer, output, x + 101, y + 25);
    }

    public void drawBackground(class_332 context, int x, int y) {
        context.method_51422(1.0F, 1.0F, 1.0F, 1.0F);
        context.method_25290(TEXTURE, x, y, 0, 0, 130, 86, 256, 256);
    }

}
