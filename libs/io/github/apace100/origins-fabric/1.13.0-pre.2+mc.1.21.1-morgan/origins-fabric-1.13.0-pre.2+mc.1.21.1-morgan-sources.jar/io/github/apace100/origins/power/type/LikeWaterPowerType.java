package io.github.apace100.origins.power.type;

import io.github.apace100.apoli.component.PowerHolderComponent;
import io.github.apace100.apoli.condition.EntityCondition;
import io.github.apace100.apoli.power.PowerConfiguration;
import io.github.apace100.apoli.power.type.PowerType;
import org.jetbrains.annotations.NotNull;

import java.util.Optional;
import net.minecraft.class_1297;
import net.minecraft.class_243;

public class LikeWaterPowerType extends PowerType {

    public LikeWaterPowerType(Optional<EntityCondition> condition) {
        super(condition);
    }

    @Override
    public @NotNull PowerConfiguration<?> getConfig() {
        return OriginsPowerTypes.LIKE_WATER;
    }

    public static class_243 modifyFluidMovement(class_1297 entity, class_243 velocity, double fallVelocity) {
        return PowerHolderComponent.hasPowerType(entity, LikeWaterPowerType.class) && Math.abs(velocity.field_1351 - fallVelocity / 16.0D) < 0.025D
            ? new class_243(velocity.field_1352, 0, velocity.field_1350)
            : velocity;
    }

}
