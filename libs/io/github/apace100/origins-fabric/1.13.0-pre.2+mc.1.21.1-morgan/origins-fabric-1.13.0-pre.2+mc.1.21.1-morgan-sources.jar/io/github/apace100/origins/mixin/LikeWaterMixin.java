package io.github.apace100.origins.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.sugar.Local;
import io.github.apace100.origins.power.type.LikeWaterPowerType;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_1309.class)
public abstract class LikeWaterMixin extends class_1297 {

    private LikeWaterMixin(class_1299<?> type, class_1937 world) {
        super(type, world);
    }

    @ModifyExpressionValue(method = "travel", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/LivingEntity;applyFluidMovingSpeed(DZLnet/minecraft/util/math/Vec3d;)Lnet/minecraft/util/math/Vec3d;"))
    private class_243 origins$modifyVerticalFluidMovingSpeed(class_243 original, @Local(ordinal = 0) double fallVelocity) {
        return LikeWaterPowerType.modifyFluidMovement(this, original, fallVelocity);
    }

}
