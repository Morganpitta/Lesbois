package io.github.apace100.origins.mixin;

import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.function.Predicate;
import net.minecraft.class_1309;
import net.minecraft.class_4051;

@Mixin(class_4051.class)
public interface TargetPredicateAccessor {

    @Nullable
    @Accessor
    Predicate<class_1309> getPredicate();

}
