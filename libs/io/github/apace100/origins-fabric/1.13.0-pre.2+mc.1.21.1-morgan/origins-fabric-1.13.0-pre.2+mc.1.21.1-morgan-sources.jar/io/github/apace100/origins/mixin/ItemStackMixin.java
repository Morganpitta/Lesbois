package io.github.apace100.origins.mixin;

import com.llamalad7.mixinextras.sugar.Local;
import io.github.apace100.origins.registry.ModDataComponentTypes;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;
import net.minecraft.class_9299;
import net.minecraft.class_9322;
import net.minecraft.class_9331;

@Mixin(class_1799.class)
public abstract class ItemStackMixin implements class_9322 {

    @Shadow
    protected abstract <T extends class_9299> void appendTooltip(class_9331<T> componentType, class_1792.class_9635 context, Consumer<class_2561> textConsumer, class_1836 type);

    @Inject(method = "getTooltip", at = @At(value = "INVOKE", target = "Lnet/minecraft/item/ItemStack;appendTooltip(Lnet/minecraft/component/ComponentType;Lnet/minecraft/item/Item$TooltipContext;Ljava/util/function/Consumer;Lnet/minecraft/item/tooltip/TooltipType;)V", ordinal = 0))
    private void origins$appendItemOriginsTooltip(class_1792.class_9635 context, @Nullable class_1657 player, class_1836 type, CallbackInfoReturnable<List<class_2561>> cir, @Local Consumer<class_2561> tooltipConsumer) {
        this.appendTooltip(ModDataComponentTypes.ORIGIN, context, tooltipConsumer, type);
    }

}
