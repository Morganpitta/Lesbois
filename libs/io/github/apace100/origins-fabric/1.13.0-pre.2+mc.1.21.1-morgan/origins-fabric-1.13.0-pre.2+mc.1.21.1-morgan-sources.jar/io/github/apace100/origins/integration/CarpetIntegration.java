package io.github.apace100.origins.integration;

import carpet.patches.EntityPlayerMPFake;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_3222;

public class CarpetIntegration {

	public static boolean isPlayerFake(class_3222 serverPlayer) {
		return FabricLoader.getInstance().isModLoaded("carpet")
			&& serverPlayer instanceof EntityPlayerMPFake;
	}

}
