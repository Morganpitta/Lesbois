package io.github.apace100.origins.networking.packet.s2c;

import io.github.apace100.origins.Origins;
import io.netty.buffer.ByteBuf;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

public class OriginsInstalledS2CPacket implements class_8710 {

	public static final OriginsInstalledS2CPacket INSTANCE = new OriginsInstalledS2CPacket();

	public static final class_9154<OriginsInstalledS2CPacket> PACKET_ID = new class_9154<>(Origins.identifier("s2c/origins_installed"));
	public static final class_9139<ByteBuf, OriginsInstalledS2CPacket> PACKET_CODEC = class_9139.method_56431(INSTANCE);

	private OriginsInstalledS2CPacket() {

	}

	@Override
	public class_9154<? extends class_8710> method_56479() {
		return PACKET_ID;
	}

}
