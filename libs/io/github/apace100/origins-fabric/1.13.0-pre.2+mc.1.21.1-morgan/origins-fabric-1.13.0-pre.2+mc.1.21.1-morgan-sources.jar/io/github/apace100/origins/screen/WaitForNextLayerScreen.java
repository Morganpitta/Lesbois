package io.github.apace100.origins.screen;

import com.mojang.blaze3d.systems.RenderSystem;
import io.github.apace100.origins.component.OriginComponent;
import io.github.apace100.origins.origin.OriginLayer;
import io.github.apace100.origins.registry.ModComponents;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;

public class WaitForNextLayerScreen extends class_437 {

    private final List<OriginLayer> layers;
    private final int index;

    private final boolean showDirtBackground;
    private int optionCount;

    protected WaitForNextLayerScreen(List<OriginLayer> layers, int index, boolean showDirtBackground) {
        super(class_2561.method_43473());
        this.layers = layers;
        this.index = index;
        this.showDirtBackground = showDirtBackground;
    }

    @Override
    protected void method_25426() {

        super.method_25426();
        assert field_22787 != null && field_22787.field_1724 != null;

        this.optionCount = layers.get(index).getOriginOptionCount(field_22787.field_1724);

    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {

        if (optionCount == 0) {
            nextOrClose();
        }

        else {
            this.method_25420(context, mouseX, mouseY, delta);
        }

    }

    @Override
    public void method_25420(class_332 context, int mouseX, int mouseY, float delta) {

        if (showDirtBackground) {
            RenderSystem.enableBlend();
            context.method_25291(OriginDisplayScreen.DIRT_BACKGROUND, 0, 0, 0, 0.0F, 0.0F, this.field_22789, this.field_22790, 32, 32);
            RenderSystem.disableBlend();
        }

        else {
            super.method_25420(context, mouseX, mouseY, delta);
        }

    }

    public void nextOrClose() {

        int layersCount = layers.size();
        assert field_22787 != null && field_22787.field_1724 != null : "Tried iterating through " + layersCount + " layer(s) with the client and its player unset!";

        OriginComponent originComponent = ModComponents.ORIGIN.get(field_22787.field_1724);
        OriginLayer layer;

        for (int index = this.index + 1; index < layersCount; index++) {

            layer = layers.get(index);

            if (!originComponent.hasOrigin(layer) && !layer.getOrigins(field_22787.field_1724).isEmpty()) {
                field_22787.method_1507(new ChooseOriginScreen(layers, index, showDirtBackground));
                return;
            }

        }

        field_22787.method_1507(null);

    }

}
