package io.github.apace100.origins.screen;

import io.github.apace100.origins.Origins;
import io.github.apace100.origins.networking.packet.c2s.ChooseOriginC2SPacket;
import io.github.apace100.origins.networking.packet.c2s.ChooseRandomOriginC2SPacket;
import io.github.apace100.origins.origin.Origin;
import io.github.apace100.origins.origin.OriginLayer;
import io.github.apace100.origins.origin.OriginManager;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_1799;
import net.minecraft.class_1809;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_4185;
import net.minecraft.class_9296;
import net.minecraft.class_9334;
import java.util.List;
import java.util.Objects;

public class ChooseOriginScreen extends OriginDisplayScreen {

	private final List<OriginLayer> layers;
	private final int layerIndex;

	private final List<Origin> origins = new ObjectArrayList<>();
	private int originIndex = 0;

	private int optionCount;

	protected ChooseOriginScreen(List<OriginLayer> layers, int layerIndex, boolean showDirtBackground) {
		super(class_2561.method_43471(Origins.MODID + ".screen.choose_origin"), showDirtBackground);
		this.layers = layers;
		this.layerIndex = class_3532.method_15340(Math.abs(layerIndex), 0, layers.size());
	}

	public ChooseOriginScreen(List<OriginLayer> layers, boolean showDirtBackground) {
		this(layers, 0, showDirtBackground);
	}

	@Override
	public boolean method_25422() {
		return false;
	}

	@Override
	protected void method_25426() {

		super.method_25426();

		assert field_22787 != null && field_22787.field_1724 != null : "Tried initializing the choose origin screen with the client and its player unset!";
		assert windowWidget != null : "Tried initializing the choose origin screen with the window widget unset!";

		this.optionCount = 0;
		this.origins.clear();

		if (layers.isEmpty()) {
			this.waitForNextLayer();
		}

		else {

			OriginLayer currentLayer = getCurrentLayer();
			this.optionCount = currentLayer.getOriginOptionCount(field_22787.field_1724);

			for (var originId : currentLayer.getOrigins(field_22787.field_1724)) {

				Origin origin = OriginManager.get(originId);
				class_1799 icon = origin.getDisplayItem();

				if (origin.isChoosable()) {

					if (icon.method_7909() instanceof class_1809 && !icon.method_57826(class_9334.field_49617)) {
						icon.method_57379(class_9334.field_49617, new class_9296(field_22787.field_1724.method_7334()));
					}

					origins.add(origin);

				}

			}

			this.origins.sort(Origin::compareTo);

			//  Manually add the random origin if random is allowed
			if (currentLayer.isRandomAllowed()) {
				origins.add(Origin.RANDOM);
			}

			if (optionCount == 0) {
				this.waitForNextLayer();
			}

			else {

				this.method_37063(class_4185.method_46430(class_2561.method_43471("origins.gui.select"), button -> this.selectOrigin())
					.method_46433(windowWidget.method_46426() + windowWidget.method_25368() / 2 - 50, windowWidget.method_46427() + windowWidget.method_25364() + 5)
					.method_46437(100, 20)
					.method_46431());

				this.showCurrent();

				if (optionCount > 1) {

					this.method_37063(class_4185.method_46430(class_2561.method_43470("<"), button -> this.previousOrigin())
						.method_46433(windowWidget.method_46426() - 40, field_22790 / 2 - 10)
						.method_46437(20, 20)
						.method_46431());
					this.method_37063(class_4185.method_46430(class_2561.method_43470(">"), button -> this.nextOrigin())
						.method_46433(windowWidget.method_46426() + windowWidget.method_25368() + 20, field_22790 / 2 - 10)
						.method_46437(20, 20)
						.method_46431());

				}

			}

		}

	}

	@Override
	public class_2561 method_25440() {
		return this.getCurrentLayer().getChooseOriginTitle();
	}

	@Override
	protected Origin getCurrentOrigin() {
		return origins.get(originIndex);
	}

	@Override
	protected OriginLayer getCurrentLayer() {
		return layers.get(layerIndex);
	}

	protected void waitForNextLayer() {
		Objects.requireNonNull(field_22787).method_1507(new WaitForNextLayerScreen(layers, layerIndex, showDirtBackground));
	}

	void selectOrigin() {

		Origin origin = getCurrentOrigin();
		OriginLayer layer = getCurrentLayer();

		if (origin == Origin.RANDOM) {
			ClientPlayNetworking.send(new ChooseRandomOriginC2SPacket(layer.getId()));
		}

		else {
			ClientPlayNetworking.send(new ChooseOriginC2SPacket(layer.getId(), origin.getId()));
		}

		waitForNextLayer();

	}

	void showCurrent() {
		this.showCurrent(origin -> origin.getGuiMetadata().choosing());
	}

	void nextOrigin() {
		this.originIndex = class_3532.method_15387(originIndex + 1, optionCount);
		this.showCurrent();
	}

	void previousOrigin() {
		this.originIndex = class_3532.method_15387(originIndex - 1, optionCount);
		this.showCurrent();
	}

}
