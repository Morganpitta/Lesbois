package io.github.apace100.origins.registry;

import net.fabricmc.fabric.api.loot.v3.LootTableEvents;
import net.minecraft.class_1802;
import net.minecraft.class_1887;
import net.minecraft.class_2960;
import net.minecraft.class_44;
import net.minecraft.class_52;
import net.minecraft.class_5321;
import net.minecraft.class_55;
import net.minecraft.class_5642;
import net.minecraft.class_6880;
import net.minecraft.class_73;
import net.minecraft.class_77;
import net.minecraft.class_7924;
import net.minecraft.registry.*;
import java.util.HashSet;
import java.util.Set;
import java.util.function.BiFunction;

public class ModLoot {

    private static final Set<class_5321<class_52>> AFFECTED_TABLES = new HashSet<>();

    private static final class_5321<class_52> SIMPLE_DUNGEON = getAndAddTable("chests/simple_dungeon");
    private static final class_5321<class_52> STRONGHOLD_LIBRARY = getAndAddTable("chests/stronghold_library");
    private static final class_5321<class_52> MINESHAFT = getAndAddTable("chests/abandoned_mineshaft");
    private static final class_5321<class_52> SMALL_UNDERWATER_RUIN = getAndAddTable("chests/underwater_ruin_small");

    private static final BiFunction<class_6880<class_1887>, Integer, class_5642.class_6158> SIMPLE_ENCHANTMENT_SETTER = (enchantmentEntry, levels) ->
        new class_5642.class_6158()
            .method_35539(enchantmentEntry, class_44.method_32448(levels));

    private static class_5321<class_52> getAndAddTable(String path) {

        class_5321<class_52> tableKey = class_5321.method_29179(class_7924.field_50079, class_2960.method_60654(path));
        AFFECTED_TABLES.add(tableKey);

        return tableKey;

    }

    public static void registerLootTables() {
        LootTableEvents.MODIFY.register((key, tableBuilder, source, registries) -> {

            if (!AFFECTED_TABLES.contains(key)) {
                return;
            }

            class_6880<class_1887> waterProtection = registries
                .method_46762(class_7924.field_41265)
                .method_46746(ModEnchantments.WATER_PROTECTION).orElse(null);

            if (waterProtection == null) return;

            if (key.equals(SIMPLE_DUNGEON)) {
                tableBuilder.method_336(new class_55.class_56()
                    .method_352(class_44.method_32448(1.0F))
                    .method_351(class_77.method_411(class_1802.field_8529)
                        .method_437(20)
                        .method_438(SIMPLE_ENCHANTMENT_SETTER.apply(waterProtection, 1)))
                    .method_351(class_77.method_411(class_1802.field_8529)
                        .method_437(10)
                        .method_438(SIMPLE_ENCHANTMENT_SETTER.apply(waterProtection, 2)))
                    .method_351(class_73.method_401()
                        .method_437(80)));
            }

            else if (key.equals(STRONGHOLD_LIBRARY)) {
                tableBuilder.method_336(new class_55.class_56()
                    .method_352(class_44.method_32448(1.0F))
                    .method_351(class_77.method_411(class_1802.field_8529)
                        .method_437(20)
                        .method_438(SIMPLE_ENCHANTMENT_SETTER.apply(waterProtection, 2)))
                    .method_351(class_77.method_411(class_1802.field_8529)
                        .method_437(10)
                        .method_438(SIMPLE_ENCHANTMENT_SETTER.apply(waterProtection, 3)))
                    .method_351(class_73.method_401()
                        .method_437(80)));
            }

            else if (key.equals(MINESHAFT)) {
                tableBuilder.method_336(new class_55.class_56()
                    .method_352(class_44.method_32448(1.0F))
                    .method_351(class_77.method_411(class_1802.field_8529)
                        .method_437(20)
                        .method_438(SIMPLE_ENCHANTMENT_SETTER.apply(waterProtection, 1)))
                    .method_351(class_77.method_411(class_1802.field_8529)
                        .method_437(5)
                        .method_438(SIMPLE_ENCHANTMENT_SETTER.apply(waterProtection, 2)))
                    .method_351(class_73.method_401()
                        .method_437(90)));
            }

            else if (key.equals(SMALL_UNDERWATER_RUIN)) {
                tableBuilder.method_336(new class_55.class_56()
                    .method_352(class_44.method_32448(1.0F))
                    .method_351(class_77.method_411(class_1802.field_8529)
                        .method_437(10)
                        .method_438(SIMPLE_ENCHANTMENT_SETTER.apply(waterProtection, 1)))
                    .method_351(class_77.method_411(class_1802.field_8529)
                        .method_437(20)
                        .method_438(SIMPLE_ENCHANTMENT_SETTER.apply(waterProtection, 2)))
                    .method_351(class_73.method_401()
                        .method_437(110)));
            }

        });
    }

}
