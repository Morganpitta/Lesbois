package io.github.apace100.origins.screen;

import com.mojang.blaze3d.systems.RenderSystem;
import io.github.apace100.origins.Origins;
import io.github.apace100.origins.origin.Origin;
import io.github.apace100.origins.origin.OriginLayer;
import io.github.apace100.origins.screen.widget.OriginWindowWidget;
import java.util.Objects;
import java.util.function.Function;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_437;

public abstract class OriginDisplayScreen extends class_437 {

    public static final class_2960 DIRT_BACKGROUND = Origins.identifier("textures/dirt_background.png");

    protected static final int WINDOW_WIDTH = 176;
    protected static final int WINDOW_HEIGHT = 182;

    protected final boolean showDirtBackground;
    protected OriginWindowWidget windowWidget;

    public OriginDisplayScreen(class_2561 title, boolean showDirtBackground) {
        super(title);
        this.showDirtBackground = showDirtBackground;
    }

    @Override
    protected void method_25426() {

        super.method_25426();

        this.windowWidget = new OriginWindowWidget((this.field_22789 - WINDOW_WIDTH) / 2, (this.field_22790 - WINDOW_HEIGHT) / 2, WINDOW_WIDTH, WINDOW_HEIGHT, field_22793);
        this.method_37063(windowWidget);

    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
        context.method_27534(field_22793, this.method_25440(), field_22789 / 2, windowWidget.method_46427() - 15, 0xFFFFFF);
    }

    @Override
    public void method_25420(class_332 context, int mouseX, int mouseY, float delta) {

        if (showDirtBackground) {
            RenderSystem.enableBlend();
            context.method_25291(DIRT_BACKGROUND, 0, 0, 0, 0.0F, 0.0F, this.field_22789, this.field_22790, 32, 32);
            RenderSystem.disableBlend();
        }

        else {
            super.method_25420(context, mouseX, mouseY, delta);
        }

    }

    @Override
    public void method_52752(class_332 context) {
        context.method_25296(0, 0, this.field_22789, this.field_22790, 1678774288, -2112876528);
    }

    protected abstract Origin getCurrentOrigin();

    protected abstract OriginLayer getCurrentLayer();

    protected void showCurrent(Function<Origin, Origin.WindowTextures> texturesGetter) {
        Objects
            .requireNonNull(windowWidget, "Tried showing an origin with the origin window widget unset!")
            .show(getCurrentOrigin(), getCurrentLayer(), texturesGetter);
    }

}
