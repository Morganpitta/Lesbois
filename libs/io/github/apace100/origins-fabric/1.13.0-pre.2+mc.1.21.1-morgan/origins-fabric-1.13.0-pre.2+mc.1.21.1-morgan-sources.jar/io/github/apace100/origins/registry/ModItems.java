package io.github.apace100.origins.registry;

import io.github.apace100.origins.Origins;
import io.github.apace100.origins.content.OrbOfOriginItem;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_7923;

public class ModItems {

    public static final class_1792 ORB_OF_ORIGIN;

    public static void register() {

    }

    static {
        ORB_OF_ORIGIN = class_2378.method_10230(class_7923.field_41178, Origins.identifier("orb_of_origin"), new OrbOfOriginItem());
    }

}
