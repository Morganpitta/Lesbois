package io.github.apace100.origins.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import io.github.apace100.apoli.component.PowerHolderComponent;
import io.github.apace100.origins.power.type.WaterBreathingPowerType;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

public final class WaterBreathingMixin {

    @Mixin(class_1309.class)
    public static abstract class BreathingImpl extends class_1297 {

        private BreathingImpl(class_1299<?> type, class_1937 world) {
            super(type, world);
        }

        @ModifyReturnValue(method = "canBreatheInWater", at = @At("RETURN"))
        private boolean origins$breatheUnderwater(boolean original) {
            return original
                || PowerHolderComponent.hasPowerType(this, WaterBreathingPowerType.class);
        }

        @Inject(method = "baseTick", at = @At("TAIL"))
        private void origins$waterBreathingTick(CallbackInfo ci) {
            WaterBreathingPowerType.tick((class_1309) (Object) this);
        }

    }

    @Mixin(class_1657.class)
    public static abstract class TurtleHelmetProxy extends class_1309 {

        private TurtleHelmetProxy(class_1299<? extends class_1309> entityType, class_1937 world) {
            super(entityType, world);
        }

        @ModifyExpressionValue(method = "updateTurtleHelmet", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/player/PlayerEntity;isSubmergedIn(Lnet/minecraft/registry/tag/TagKey;)Z"))
        private boolean origins$submergedProxy(boolean original) {
            return PowerHolderComponent.hasPowerType(this, WaterBreathingPowerType.class) != original;
        }

    }

}
