package io.github.apace100.origins.screen.widget;

import io.github.apace100.apoli.power.Power;
import io.github.apace100.origins.badge.Badge;
import io.github.apace100.origins.mixin.DrawContextAccessor;
import io.github.apace100.origins.screen.TooltipDrawer;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_437;
import net.minecraft.class_5684;
import net.minecraft.class_6382;
import net.minecraft.class_8001;

public final class BadgeWidget extends class_339 implements TooltipDrawer {

	private final Power power;
	private final Badge badge;

	public BadgeWidget(Power power, Badge badge, int x, int y) {
		super(x, y, 9, 9, class_2561.method_43473());
		this.power = power;
		this.badge = badge;
	}

	@Override
	protected void method_48579(class_332 context, int mouseX, int mouseY, float delta) {
		context.method_25290(badge.spriteId(), this.method_46426(), this.method_46427(), 0, 0, 9, 9, 9, 9);
	}

	@Override
	public void renderTooltip(class_327 textRenderer, class_332 context, int mouseX, int mouseY, float delta) {

		class_310 client = class_310.method_1551();
		class_437 currentScreen = client.field_1755;

		if (currentScreen != null) {
			((DrawContextAccessor) context).invokeDrawTooltip(textRenderer, this.getTooltipComponents(textRenderer, currentScreen.field_22789 - mouseX - 24, delta), mouseX, mouseY, class_8001.field_41687);
		}

	}

	@Override
	protected void method_47399(class_6382 builder) {

	}

	public List<class_5684> getTooltipComponents(class_327 textRenderer, int widthLimit, float delta) {
		return badge.getTooltipComponents(power, widthLimit, delta, textRenderer);
	}

	public boolean hasTooltip() {
		return badge.hasTooltip();
	}

}
